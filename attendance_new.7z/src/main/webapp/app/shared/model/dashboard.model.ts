import { Moment } from 'moment';
import { IEmployee } from 'app/shared/model//employee.model';

export interface IDashboard {
    id?: number;
    permission?: number;
    ordinary?: number;
    delivery?: number;
    marriage?: number;
    reportdate?: Moment;
    weeknumber?: string;
    reportmonth?: Moment;
    employee?: IEmployee;
}

export class Dashboard implements IDashboard {
    constructor(
        public id?: number,
        public permission?: number,
        public ordinary?: number,
        public delivery?: number,
        public marriage?: number,
        public reportdate?: Moment,
        public weeknumber?: string,
        public reportmonth?: Moment,
        public employee?: IEmployee
    ) {}
}
