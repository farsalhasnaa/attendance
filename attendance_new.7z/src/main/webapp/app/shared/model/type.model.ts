import { IEmployee } from 'app/shared/model//employee.model';

export interface IType {
    id?: number;
    type?: string;
    employees?: IEmployee[];
}

export class Type implements IType {
    constructor(public id?: number, public type?: string, public employees?: IEmployee[]) {}
}
