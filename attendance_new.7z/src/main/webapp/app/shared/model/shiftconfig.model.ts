import { Moment } from 'moment';
import { IEmployee } from 'app/shared/model//employee.model';

export interface IShiftconfig {
    id?: number;
    shiftname?: string;
    shiftstart?: Moment;
    shiftend?: Moment;
    employees?: IEmployee[];
}

export class Shiftconfig implements IShiftconfig {
    constructor(
        public id?: number,
        public shiftname?: string,
        public shiftstart?: Moment,
        public shiftend?: Moment,
        public employees?: IEmployee[]
    ) {}
}
