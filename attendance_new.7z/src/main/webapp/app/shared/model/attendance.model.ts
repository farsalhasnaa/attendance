import { Moment } from 'moment';
import { IEmployee } from 'app/shared/model//employee.model';

export interface IAttendance {
    id?: number;
    entrytime?: Moment;
    exittime?: Moment;
    attend?: boolean;
    note?: string;
    workinghours?: number;
    latehours?: number;
    permissionhours?: number;
    totalhours?: number;
    exitconfirmation?: boolean;
    employee?: IEmployee;
}

export class Attendance implements IAttendance {
    constructor(
        public id?: number,
        public entrytime?: Moment,
        public exittime?: Moment,
        public attend?: boolean,
        public note?: string,
        public workinghours?: number,
        public latehours?: number,
        public permissionhours?: number,
        public totalhours?: number,
        public exitconfirmation?: boolean,
        public employee?: IEmployee
    ) {
        this.attend = this.attend || false;
        this.exitconfirmation = this.exitconfirmation || false;
    }
}
