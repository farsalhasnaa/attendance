import { Moment } from 'moment';
import { IEmployee } from 'app/shared/model//employee.model';
import { IVacationtype } from 'app/shared/model//vacationtype.model';

export interface IEmpvacation {
    id?: number;
    startdate?: Moment;
    enddate?: Moment;
    employee?: IEmployee;
    vacationtype?: IVacationtype;
}

export class Empvacation implements IEmpvacation {
    constructor(
        public id?: number,
        public startdate?: Moment,
        public enddate?: Moment,
        public employee?: IEmployee,
        public vacationtype?: IVacationtype
    ) {}
}
