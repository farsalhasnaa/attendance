import { IEmpvacation } from 'app/shared/model//empvacation.model';

export interface IVacationtype {
    id?: number;
    vacationname?: string;
    empvacations?: IEmpvacation[];
}

export class Vacationtype implements IVacationtype {
    constructor(public id?: number, public vacationname?: string, public empvacations?: IEmpvacation[]) {}
}
