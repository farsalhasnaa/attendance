import { IType } from 'app/shared/model//type.model';
import { IShiftconfig } from 'app/shared/model//shiftconfig.model';
import { IEmpvacation } from 'app/shared/model//empvacation.model';
import { IDashboard } from 'app/shared/model//dashboard.model';
import { IAttendance } from 'app/shared/model//attendance.model';

export interface IEmployee {
    id?: number;
    staffid?: string;
    fullname?: string;
    note?: string;
    type?: IType;
    shiftconfig?: IShiftconfig;
    empvacations?: IEmpvacation[];
    dashboards?: IDashboard[];
    attendances?: IAttendance[];
}

export class Employee implements IEmployee {
    constructor(
        public id?: number,
        public staffid?: string,
        public fullname?: string,
        public note?: string,
        public type?: IType,
        public shiftconfig?: IShiftconfig,
        public empvacations?: IEmpvacation[],
        public dashboards?: IDashboard[],
        public attendances?: IAttendance[]
    ) {}
}
