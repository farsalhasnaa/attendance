import { Moment } from 'moment';

export interface IHoliday {
    id?: number;
    name?: string;
    startdate?: Moment;
    enddate?: Moment;
}

export class Holiday implements IHoliday {
    constructor(public id?: number, public name?: string, public startdate?: Moment, public enddate?: Moment) {}
}
