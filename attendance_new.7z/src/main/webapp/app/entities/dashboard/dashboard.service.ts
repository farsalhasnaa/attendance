import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_FORMAT } from 'app/shared/constants/input.constants';
import { map } from 'rxjs/operators';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IDashboard } from 'app/shared/model/dashboard.model';

type EntityResponseType = HttpResponse<IDashboard>;
type EntityArrayResponseType = HttpResponse<IDashboard[]>;

@Injectable({ providedIn: 'root' })
export class DashboardService {
    public resourceUrl = SERVER_API_URL + 'api/dashboards';
    public resourceSearchUrl = SERVER_API_URL + 'api/_search/dashboards';

    constructor(protected http: HttpClient) {}

    create(dashboard: IDashboard): Observable<EntityResponseType> {
        const copy = this.convertDateFromClient(dashboard);
        return this.http
            .post<IDashboard>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    update(dashboard: IDashboard): Observable<EntityResponseType> {
        const copy = this.convertDateFromClient(dashboard);
        return this.http
            .put<IDashboard>(this.resourceUrl, copy, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http
            .get<IDashboard>(`${this.resourceUrl}/${id}`, { observe: 'response' })
            .pipe(map((res: EntityResponseType) => this.convertDateFromServer(res)));
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http
            .get<IDashboard[]>(this.resourceUrl, { params: options, observe: 'response' })
            .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http
            .get<IDashboard[]>(this.resourceSearchUrl, { params: options, observe: 'response' })
            .pipe(map((res: EntityArrayResponseType) => this.convertDateArrayFromServer(res)));
    }

    protected convertDateFromClient(dashboard: IDashboard): IDashboard {
        const copy: IDashboard = Object.assign({}, dashboard, {
            reportdate: dashboard.reportdate != null && dashboard.reportdate.isValid() ? dashboard.reportdate.format(DATE_FORMAT) : null,
            reportmonth: dashboard.reportmonth != null && dashboard.reportmonth.isValid() ? dashboard.reportmonth.format(DATE_FORMAT) : null
        });
        return copy;
    }

    protected convertDateFromServer(res: EntityResponseType): EntityResponseType {
        if (res.body) {
            res.body.reportdate = res.body.reportdate != null ? moment(res.body.reportdate) : null;
            res.body.reportmonth = res.body.reportmonth != null ? moment(res.body.reportmonth) : null;
        }
        return res;
    }

    protected convertDateArrayFromServer(res: EntityArrayResponseType): EntityArrayResponseType {
        if (res.body) {
            res.body.forEach((dashboard: IDashboard) => {
                dashboard.reportdate = dashboard.reportdate != null ? moment(dashboard.reportdate) : null;
                dashboard.reportmonth = dashboard.reportmonth != null ? moment(dashboard.reportmonth) : null;
            });
        }
        return res;
    }
}
