export * from './dashboard.service';
export * from './dashboard-update.component';
export * from './dashboard-delete-dialog.component';
export * from './dashboard-detail.component';
export * from './dashboard.component';
export * from './dashboard.route';
