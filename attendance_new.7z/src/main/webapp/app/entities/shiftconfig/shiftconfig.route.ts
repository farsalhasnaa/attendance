import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Shiftconfig } from 'app/shared/model/shiftconfig.model';
import { ShiftconfigService } from './shiftconfig.service';
import { ShiftconfigComponent } from './shiftconfig.component';
import { ShiftconfigDetailComponent } from './shiftconfig-detail.component';
import { ShiftconfigUpdateComponent } from './shiftconfig-update.component';
import { ShiftconfigDeletePopupComponent } from './shiftconfig-delete-dialog.component';
import { IShiftconfig } from 'app/shared/model/shiftconfig.model';

@Injectable({ providedIn: 'root' })
export class ShiftconfigResolve implements Resolve<IShiftconfig> {
    constructor(private service: ShiftconfigService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Shiftconfig> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Shiftconfig>) => response.ok),
                map((shiftconfig: HttpResponse<Shiftconfig>) => shiftconfig.body)
            );
        }
        return of(new Shiftconfig());
    }
}

export const shiftconfigRoute: Routes = [
    {
        path: 'shiftconfig',
        component: ShiftconfigComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.shiftconfig.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'shiftconfig/:id/view',
        component: ShiftconfigDetailComponent,
        resolve: {
            shiftconfig: ShiftconfigResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.shiftconfig.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'shiftconfig/new',
        component: ShiftconfigUpdateComponent,
        resolve: {
            shiftconfig: ShiftconfigResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.shiftconfig.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'shiftconfig/:id/edit',
        component: ShiftconfigUpdateComponent,
        resolve: {
            shiftconfig: ShiftconfigResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.shiftconfig.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const shiftconfigPopupRoute: Routes = [
    {
        path: 'shiftconfig/:id/delete',
        component: ShiftconfigDeletePopupComponent,
        resolve: {
            shiftconfig: ShiftconfigResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.shiftconfig.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
