import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IShiftconfig } from 'app/shared/model/shiftconfig.model';

@Component({
    selector: 'jhi-shiftconfig-detail',
    templateUrl: './shiftconfig-detail.component.html'
})
export class ShiftconfigDetailComponent implements OnInit {
    shiftconfig: IShiftconfig;

    constructor(protected activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ shiftconfig }) => {
            this.shiftconfig = shiftconfig;
        });
    }

    previousState() {
        window.history.back();
    }
}
