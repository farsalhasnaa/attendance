import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IShiftconfig } from 'app/shared/model/shiftconfig.model';
import { ShiftconfigService } from './shiftconfig.service';

@Component({
    selector: 'jhi-shiftconfig-delete-dialog',
    templateUrl: './shiftconfig-delete-dialog.component.html'
})
export class ShiftconfigDeleteDialogComponent {
    shiftconfig: IShiftconfig;

    constructor(
        protected shiftconfigService: ShiftconfigService,
        public activeModal: NgbActiveModal,
        protected eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.shiftconfigService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'shiftconfigListModification',
                content: 'Deleted an shiftconfig'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-shiftconfig-delete-popup',
    template: ''
})
export class ShiftconfigDeletePopupComponent implements OnInit, OnDestroy {
    protected ngbModalRef: NgbModalRef;

    constructor(protected activatedRoute: ActivatedRoute, protected router: Router, protected modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ shiftconfig }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(ShiftconfigDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.shiftconfig = shiftconfig;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
