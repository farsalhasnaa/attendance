import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { JhipSharedModule } from 'app/shared';
import {
    ShiftconfigComponent,
    ShiftconfigDetailComponent,
    ShiftconfigUpdateComponent,
    ShiftconfigDeletePopupComponent,
    ShiftconfigDeleteDialogComponent,
    shiftconfigRoute,
    shiftconfigPopupRoute
} from './';

const ENTITY_STATES = [...shiftconfigRoute, ...shiftconfigPopupRoute];

@NgModule({
    imports: [JhipSharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        ShiftconfigComponent,
        ShiftconfigDetailComponent,
        ShiftconfigUpdateComponent,
        ShiftconfigDeleteDialogComponent,
        ShiftconfigDeletePopupComponent
    ],
    entryComponents: [ShiftconfigComponent, ShiftconfigUpdateComponent, ShiftconfigDeleteDialogComponent, ShiftconfigDeletePopupComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class JhipShiftconfigModule {}
