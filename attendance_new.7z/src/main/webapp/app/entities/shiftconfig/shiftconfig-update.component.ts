import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';

import { IShiftconfig } from 'app/shared/model/shiftconfig.model';
import { ShiftconfigService } from './shiftconfig.service';

@Component({
    selector: 'jhi-shiftconfig-update',
    templateUrl: './shiftconfig-update.component.html'
})
export class ShiftconfigUpdateComponent implements OnInit {
    shiftconfig: IShiftconfig;
    isSaving: boolean;
    shiftstart: string;
    shiftend: string;

    constructor(protected shiftconfigService: ShiftconfigService, protected activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ shiftconfig }) => {
            this.shiftconfig = shiftconfig;
            this.shiftstart = this.shiftconfig.shiftstart != null ? this.shiftconfig.shiftstart.format(DATE_TIME_FORMAT) : null;
            this.shiftend = this.shiftconfig.shiftend != null ? this.shiftconfig.shiftend.format(DATE_TIME_FORMAT) : null;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        this.shiftconfig.shiftstart = this.shiftstart != null ? moment(this.shiftstart, DATE_TIME_FORMAT) : null;
        this.shiftconfig.shiftend = this.shiftend != null ? moment(this.shiftend, DATE_TIME_FORMAT) : null;
        if (this.shiftconfig.id !== undefined) {
            this.subscribeToSaveResponse(this.shiftconfigService.update(this.shiftconfig));
        } else {
            this.subscribeToSaveResponse(this.shiftconfigService.create(this.shiftconfig));
        }
    }

    protected subscribeToSaveResponse(result: Observable<HttpResponse<IShiftconfig>>) {
        result.subscribe((res: HttpResponse<IShiftconfig>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    protected onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    protected onSaveError() {
        this.isSaving = false;
    }
}
