export * from './type.service';
export * from './type-update.component';
export * from './type-delete-dialog.component';
export * from './type-detail.component';
export * from './type.component';
export * from './type.route';
