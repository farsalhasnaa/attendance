import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';
import { JhiAlertService } from 'ng-jhipster';

import { IEmpvacation } from 'app/shared/model/empvacation.model';
import { EmpvacationService } from './empvacation.service';
import { IEmployee } from 'app/shared/model/employee.model';
import { EmployeeService } from 'app/entities/employee';
import { IVacationtype } from 'app/shared/model/vacationtype.model';
import { VacationtypeService } from 'app/entities/vacationtype';

@Component({
    selector: 'jhi-empvacation-update',
    templateUrl: './empvacation-update.component.html'
})
export class EmpvacationUpdateComponent implements OnInit {
    empvacation: IEmpvacation;
    isSaving: boolean;

    employees: IEmployee[];

    vacationtypes: IVacationtype[];
    startdate: string;
    enddate: string;

    constructor(
        protected jhiAlertService: JhiAlertService,
        protected empvacationService: EmpvacationService,
        protected employeeService: EmployeeService,
        protected vacationtypeService: VacationtypeService,
        protected activatedRoute: ActivatedRoute
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ empvacation }) => {
            this.empvacation = empvacation;
            this.startdate = this.empvacation.startdate != null ? this.empvacation.startdate.format(DATE_TIME_FORMAT) : null;
            this.enddate = this.empvacation.enddate != null ? this.empvacation.enddate.format(DATE_TIME_FORMAT) : null;
        });
        this.employeeService.query().subscribe(
            (res: HttpResponse<IEmployee[]>) => {
                this.employees = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
        this.vacationtypeService.query().subscribe(
            (res: HttpResponse<IVacationtype[]>) => {
                this.vacationtypes = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        this.empvacation.startdate = this.startdate != null ? moment(this.startdate, DATE_TIME_FORMAT) : null;
        this.empvacation.enddate = this.enddate != null ? moment(this.enddate, DATE_TIME_FORMAT) : null;
        if (this.empvacation.id !== undefined) {
            this.subscribeToSaveResponse(this.empvacationService.update(this.empvacation));
        } else {
            this.subscribeToSaveResponse(this.empvacationService.create(this.empvacation));
        }
    }

    protected subscribeToSaveResponse(result: Observable<HttpResponse<IEmpvacation>>) {
        result.subscribe((res: HttpResponse<IEmpvacation>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    protected onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    protected onSaveError() {
        this.isSaving = false;
    }

    protected onError(errorMessage: string) {
        this.jhiAlertService.error(errorMessage, null, null);
    }

    trackEmployeeById(index: number, item: IEmployee) {
        return item.id;
    }

    trackVacationtypeById(index: number, item: IVacationtype) {
        return item.id;
    }
}
