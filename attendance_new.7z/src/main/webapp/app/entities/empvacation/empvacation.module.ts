import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { JhipSharedModule } from 'app/shared';
import {
    EmpvacationComponent,
    EmpvacationDetailComponent,
    EmpvacationUpdateComponent,
    EmpvacationDeletePopupComponent,
    EmpvacationDeleteDialogComponent,
    empvacationRoute,
    empvacationPopupRoute
} from './';

const ENTITY_STATES = [...empvacationRoute, ...empvacationPopupRoute];

@NgModule({
    imports: [JhipSharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        EmpvacationComponent,
        EmpvacationDetailComponent,
        EmpvacationUpdateComponent,
        EmpvacationDeleteDialogComponent,
        EmpvacationDeletePopupComponent
    ],
    entryComponents: [EmpvacationComponent, EmpvacationUpdateComponent, EmpvacationDeleteDialogComponent, EmpvacationDeletePopupComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class JhipEmpvacationModule {}
