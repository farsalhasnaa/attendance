import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IEmpvacation } from 'app/shared/model/empvacation.model';

@Component({
    selector: 'jhi-empvacation-detail',
    templateUrl: './empvacation-detail.component.html'
})
export class EmpvacationDetailComponent implements OnInit {
    empvacation: IEmpvacation;

    constructor(protected activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ empvacation }) => {
            this.empvacation = empvacation;
        });
    }

    previousState() {
        window.history.back();
    }
}
