import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IEmpvacation } from 'app/shared/model/empvacation.model';
import { EmpvacationService } from './empvacation.service';

@Component({
    selector: 'jhi-empvacation-delete-dialog',
    templateUrl: './empvacation-delete-dialog.component.html'
})
export class EmpvacationDeleteDialogComponent {
    empvacation: IEmpvacation;

    constructor(
        protected empvacationService: EmpvacationService,
        public activeModal: NgbActiveModal,
        protected eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.empvacationService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'empvacationListModification',
                content: 'Deleted an empvacation'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-empvacation-delete-popup',
    template: ''
})
export class EmpvacationDeletePopupComponent implements OnInit, OnDestroy {
    protected ngbModalRef: NgbModalRef;

    constructor(protected activatedRoute: ActivatedRoute, protected router: Router, protected modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ empvacation }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(EmpvacationDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.empvacation = empvacation;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
