import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Empvacation } from 'app/shared/model/empvacation.model';
import { EmpvacationService } from './empvacation.service';
import { EmpvacationComponent } from './empvacation.component';
import { EmpvacationDetailComponent } from './empvacation-detail.component';
import { EmpvacationUpdateComponent } from './empvacation-update.component';
import { EmpvacationDeletePopupComponent } from './empvacation-delete-dialog.component';
import { IEmpvacation } from 'app/shared/model/empvacation.model';

@Injectable({ providedIn: 'root' })
export class EmpvacationResolve implements Resolve<IEmpvacation> {
    constructor(private service: EmpvacationService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Empvacation> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Empvacation>) => response.ok),
                map((empvacation: HttpResponse<Empvacation>) => empvacation.body)
            );
        }
        return of(new Empvacation());
    }
}

export const empvacationRoute: Routes = [
    {
        path: 'empvacation',
        component: EmpvacationComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.empvacation.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'empvacation/:id/view',
        component: EmpvacationDetailComponent,
        resolve: {
            empvacation: EmpvacationResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.empvacation.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'empvacation/new',
        component: EmpvacationUpdateComponent,
        resolve: {
            empvacation: EmpvacationResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.empvacation.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'empvacation/:id/edit',
        component: EmpvacationUpdateComponent,
        resolve: {
            empvacation: EmpvacationResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.empvacation.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const empvacationPopupRoute: Routes = [
    {
        path: 'empvacation/:id/delete',
        component: EmpvacationDeletePopupComponent,
        resolve: {
            empvacation: EmpvacationResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.empvacation.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
