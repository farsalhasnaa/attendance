import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { JhiEventManager } from 'ng-jhipster';

import { IVacationtype } from 'app/shared/model/vacationtype.model';
import { VacationtypeService } from './vacationtype.service';

@Component({
    selector: 'jhi-vacationtype-delete-dialog',
    templateUrl: './vacationtype-delete-dialog.component.html'
})
export class VacationtypeDeleteDialogComponent {
    vacationtype: IVacationtype;

    constructor(
        protected vacationtypeService: VacationtypeService,
        public activeModal: NgbActiveModal,
        protected eventManager: JhiEventManager
    ) {}

    clear() {
        this.activeModal.dismiss('cancel');
    }

    confirmDelete(id: number) {
        this.vacationtypeService.delete(id).subscribe(response => {
            this.eventManager.broadcast({
                name: 'vacationtypeListModification',
                content: 'Deleted an vacationtype'
            });
            this.activeModal.dismiss(true);
        });
    }
}

@Component({
    selector: 'jhi-vacationtype-delete-popup',
    template: ''
})
export class VacationtypeDeletePopupComponent implements OnInit, OnDestroy {
    protected ngbModalRef: NgbModalRef;

    constructor(protected activatedRoute: ActivatedRoute, protected router: Router, protected modalService: NgbModal) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ vacationtype }) => {
            setTimeout(() => {
                this.ngbModalRef = this.modalService.open(VacationtypeDeleteDialogComponent as Component, {
                    size: 'lg',
                    backdrop: 'static'
                });
                this.ngbModalRef.componentInstance.vacationtype = vacationtype;
                this.ngbModalRef.result.then(
                    result => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    },
                    reason => {
                        this.router.navigate([{ outlets: { popup: null } }], { replaceUrl: true, queryParamsHandling: 'merge' });
                        this.ngbModalRef = null;
                    }
                );
            }, 0);
        });
    }

    ngOnDestroy() {
        this.ngbModalRef = null;
    }
}
