import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterModule } from '@angular/router';

import { JhipSharedModule } from 'app/shared';
import {
    VacationtypeComponent,
    VacationtypeDetailComponent,
    VacationtypeUpdateComponent,
    VacationtypeDeletePopupComponent,
    VacationtypeDeleteDialogComponent,
    vacationtypeRoute,
    vacationtypePopupRoute
} from './';

const ENTITY_STATES = [...vacationtypeRoute, ...vacationtypePopupRoute];

@NgModule({
    imports: [JhipSharedModule, RouterModule.forChild(ENTITY_STATES)],
    declarations: [
        VacationtypeComponent,
        VacationtypeDetailComponent,
        VacationtypeUpdateComponent,
        VacationtypeDeleteDialogComponent,
        VacationtypeDeletePopupComponent
    ],
    entryComponents: [
        VacationtypeComponent,
        VacationtypeUpdateComponent,
        VacationtypeDeleteDialogComponent,
        VacationtypeDeletePopupComponent
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class JhipVacationtypeModule {}
