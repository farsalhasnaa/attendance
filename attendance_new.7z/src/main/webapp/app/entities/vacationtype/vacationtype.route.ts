import { Injectable } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot, Routes } from '@angular/router';
import { UserRouteAccessService } from 'app/core';
import { Observable, of } from 'rxjs';
import { filter, map } from 'rxjs/operators';
import { Vacationtype } from 'app/shared/model/vacationtype.model';
import { VacationtypeService } from './vacationtype.service';
import { VacationtypeComponent } from './vacationtype.component';
import { VacationtypeDetailComponent } from './vacationtype-detail.component';
import { VacationtypeUpdateComponent } from './vacationtype-update.component';
import { VacationtypeDeletePopupComponent } from './vacationtype-delete-dialog.component';
import { IVacationtype } from 'app/shared/model/vacationtype.model';

@Injectable({ providedIn: 'root' })
export class VacationtypeResolve implements Resolve<IVacationtype> {
    constructor(private service: VacationtypeService) {}

    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<Vacationtype> {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.find(id).pipe(
                filter((response: HttpResponse<Vacationtype>) => response.ok),
                map((vacationtype: HttpResponse<Vacationtype>) => vacationtype.body)
            );
        }
        return of(new Vacationtype());
    }
}

export const vacationtypeRoute: Routes = [
    {
        path: 'vacationtype',
        component: VacationtypeComponent,
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.vacationtype.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'vacationtype/:id/view',
        component: VacationtypeDetailComponent,
        resolve: {
            vacationtype: VacationtypeResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.vacationtype.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'vacationtype/new',
        component: VacationtypeUpdateComponent,
        resolve: {
            vacationtype: VacationtypeResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.vacationtype.home.title'
        },
        canActivate: [UserRouteAccessService]
    },
    {
        path: 'vacationtype/:id/edit',
        component: VacationtypeUpdateComponent,
        resolve: {
            vacationtype: VacationtypeResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.vacationtype.home.title'
        },
        canActivate: [UserRouteAccessService]
    }
];

export const vacationtypePopupRoute: Routes = [
    {
        path: 'vacationtype/:id/delete',
        component: VacationtypeDeletePopupComponent,
        resolve: {
            vacationtype: VacationtypeResolve
        },
        data: {
            authorities: ['ROLE_USER'],
            pageTitle: 'jhipApp.vacationtype.home.title'
        },
        canActivate: [UserRouteAccessService],
        outlet: 'popup'
    }
];
