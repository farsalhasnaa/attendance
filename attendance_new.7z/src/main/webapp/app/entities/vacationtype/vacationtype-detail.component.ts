import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { IVacationtype } from 'app/shared/model/vacationtype.model';

@Component({
    selector: 'jhi-vacationtype-detail',
    templateUrl: './vacationtype-detail.component.html'
})
export class VacationtypeDetailComponent implements OnInit {
    vacationtype: IVacationtype;

    constructor(protected activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.activatedRoute.data.subscribe(({ vacationtype }) => {
            this.vacationtype = vacationtype;
        });
    }

    previousState() {
        window.history.back();
    }
}
