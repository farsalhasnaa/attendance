import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { IVacationtype } from 'app/shared/model/vacationtype.model';
import { VacationtypeService } from './vacationtype.service';

@Component({
    selector: 'jhi-vacationtype-update',
    templateUrl: './vacationtype-update.component.html'
})
export class VacationtypeUpdateComponent implements OnInit {
    vacationtype: IVacationtype;
    isSaving: boolean;

    constructor(protected vacationtypeService: VacationtypeService, protected activatedRoute: ActivatedRoute) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ vacationtype }) => {
            this.vacationtype = vacationtype;
        });
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        if (this.vacationtype.id !== undefined) {
            this.subscribeToSaveResponse(this.vacationtypeService.update(this.vacationtype));
        } else {
            this.subscribeToSaveResponse(this.vacationtypeService.create(this.vacationtype));
        }
    }

    protected subscribeToSaveResponse(result: Observable<HttpResponse<IVacationtype>>) {
        result.subscribe((res: HttpResponse<IVacationtype>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    protected onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    protected onSaveError() {
        this.isSaving = false;
    }
}
