import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';

import { SERVER_API_URL } from 'app/app.constants';
import { createRequestOption } from 'app/shared';
import { IVacationtype } from 'app/shared/model/vacationtype.model';

type EntityResponseType = HttpResponse<IVacationtype>;
type EntityArrayResponseType = HttpResponse<IVacationtype[]>;

@Injectable({ providedIn: 'root' })
export class VacationtypeService {
    public resourceUrl = SERVER_API_URL + 'api/vacationtypes';
    public resourceSearchUrl = SERVER_API_URL + 'api/_search/vacationtypes';

    constructor(protected http: HttpClient) {}

    create(vacationtype: IVacationtype): Observable<EntityResponseType> {
        return this.http.post<IVacationtype>(this.resourceUrl, vacationtype, { observe: 'response' });
    }

    update(vacationtype: IVacationtype): Observable<EntityResponseType> {
        return this.http.put<IVacationtype>(this.resourceUrl, vacationtype, { observe: 'response' });
    }

    find(id: number): Observable<EntityResponseType> {
        return this.http.get<IVacationtype>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    query(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVacationtype[]>(this.resourceUrl, { params: options, observe: 'response' });
    }

    delete(id: number): Observable<HttpResponse<any>> {
        return this.http.delete<any>(`${this.resourceUrl}/${id}`, { observe: 'response' });
    }

    search(req?: any): Observable<EntityArrayResponseType> {
        const options = createRequestOption(req);
        return this.http.get<IVacationtype[]>(this.resourceSearchUrl, { params: options, observe: 'response' });
    }
}
