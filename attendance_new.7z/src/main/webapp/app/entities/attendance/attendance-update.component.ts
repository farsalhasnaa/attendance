import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import * as moment from 'moment';
import { DATE_TIME_FORMAT } from 'app/shared/constants/input.constants';
import { JhiAlertService } from 'ng-jhipster';

import { IAttendance } from 'app/shared/model/attendance.model';
import { AttendanceService } from './attendance.service';
import { IEmployee } from 'app/shared/model/employee.model';
import { EmployeeService } from 'app/entities/employee';

@Component({
    selector: 'jhi-attendance-update',
    templateUrl: './attendance-update.component.html'
})
export class AttendanceUpdateComponent implements OnInit {
    attendance: IAttendance;
    isSaving: boolean;

    employees: IEmployee[];
    entrytime: string;
    exittime: string;

    constructor(
        protected jhiAlertService: JhiAlertService,
        protected attendanceService: AttendanceService,
        protected employeeService: EmployeeService,
        protected activatedRoute: ActivatedRoute
    ) {}

    ngOnInit() {
        this.isSaving = false;
        this.activatedRoute.data.subscribe(({ attendance }) => {
            this.attendance = attendance;
            this.entrytime = this.attendance.entrytime != null ? this.attendance.entrytime.format(DATE_TIME_FORMAT) : null;
            this.exittime = this.attendance.exittime != null ? this.attendance.exittime.format(DATE_TIME_FORMAT) : null;
        });
        this.employeeService.query().subscribe(
            (res: HttpResponse<IEmployee[]>) => {
                this.employees = res.body;
            },
            (res: HttpErrorResponse) => this.onError(res.message)
        );
    }

    previousState() {
        window.history.back();
    }

    save() {
        this.isSaving = true;
        this.attendance.entrytime = this.entrytime != null ? moment(this.entrytime, DATE_TIME_FORMAT) : null;
        this.attendance.exittime = this.exittime != null ? moment(this.exittime, DATE_TIME_FORMAT) : null;
        if (this.attendance.id !== undefined) {
            this.subscribeToSaveResponse(this.attendanceService.update(this.attendance));
        } else {
            this.subscribeToSaveResponse(this.attendanceService.create(this.attendance));
        }
    }

    protected subscribeToSaveResponse(result: Observable<HttpResponse<IAttendance>>) {
        result.subscribe((res: HttpResponse<IAttendance>) => this.onSaveSuccess(), (res: HttpErrorResponse) => this.onSaveError());
    }

    protected onSaveSuccess() {
        this.isSaving = false;
        this.previousState();
    }

    protected onSaveError() {
        this.isSaving = false;
    }

    protected onError(errorMessage: string) {
        this.jhiAlertService.error(errorMessage, null, null);
    }

    trackEmployeeById(index: number, item: IEmployee) {
        return item.id;
    }
}
