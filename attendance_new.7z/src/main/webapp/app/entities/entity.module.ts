import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { JhipEmployeeModule } from './employee/employee.module';
import { JhipTypeModule } from './type/type.module';
import { JhipShiftconfigModule } from './shiftconfig/shiftconfig.module';
import { JhipVacationtypeModule } from './vacationtype/vacationtype.module';
import { JhipEmpvacationModule } from './empvacation/empvacation.module';
import { JhipDashboardModule } from './dashboard/dashboard.module';
import { JhipAttendanceModule } from './attendance/attendance.module';
import { JhipHolidayModule } from './holiday/holiday.module';
/* jhipster-needle-add-entity-module-import - JHipster will add entity modules imports here */

@NgModule({
    // prettier-ignore
    imports: [
        JhipEmployeeModule,
        JhipTypeModule,
        JhipShiftconfigModule,
        JhipVacationtypeModule,
        JhipEmpvacationModule,
        JhipDashboardModule,
        JhipAttendanceModule,
        JhipHolidayModule,
        /* jhipster-needle-add-entity-module - JHipster will add entity modules here */
    ],
    declarations: [],
    entryComponents: [],
    providers: [],
    schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class JhipEntityModule {}
