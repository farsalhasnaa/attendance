package com.mycompany.myapp.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.mycompany.myapp.domain.Vacationtype;
import com.mycompany.myapp.repository.VacationtypeRepository;
import com.mycompany.myapp.repository.search.VacationtypeSearchRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import com.mycompany.myapp.web.rest.util.HeaderUtil;
import com.mycompany.myapp.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Vacationtype.
 */
@RestController
@RequestMapping("/api")
public class VacationtypeResource {

    private final Logger log = LoggerFactory.getLogger(VacationtypeResource.class);

    private static final String ENTITY_NAME = "vacationtype";

    private final VacationtypeRepository vacationtypeRepository;

    private final VacationtypeSearchRepository vacationtypeSearchRepository;

    public VacationtypeResource(VacationtypeRepository vacationtypeRepository, VacationtypeSearchRepository vacationtypeSearchRepository) {
        this.vacationtypeRepository = vacationtypeRepository;
        this.vacationtypeSearchRepository = vacationtypeSearchRepository;
    }

    /**
     * POST  /vacationtypes : Create a new vacationtype.
     *
     * @param vacationtype the vacationtype to create
     * @return the ResponseEntity with status 201 (Created) and with body the new vacationtype, or with status 400 (Bad Request) if the vacationtype has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/vacationtypes")
    @Timed
    public ResponseEntity<Vacationtype> createVacationtype(@Valid @RequestBody Vacationtype vacationtype) throws URISyntaxException {
        log.debug("REST request to save Vacationtype : {}", vacationtype);
        if (vacationtype.getId() != null) {
            throw new BadRequestAlertException("A new vacationtype cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Vacationtype result = vacationtypeRepository.save(vacationtype);
        vacationtypeSearchRepository.save(result);
        return ResponseEntity.created(new URI("/api/vacationtypes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /vacationtypes : Updates an existing vacationtype.
     *
     * @param vacationtype the vacationtype to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated vacationtype,
     * or with status 400 (Bad Request) if the vacationtype is not valid,
     * or with status 500 (Internal Server Error) if the vacationtype couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/vacationtypes")
    @Timed
    public ResponseEntity<Vacationtype> updateVacationtype(@Valid @RequestBody Vacationtype vacationtype) throws URISyntaxException {
        log.debug("REST request to update Vacationtype : {}", vacationtype);
        if (vacationtype.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Vacationtype result = vacationtypeRepository.save(vacationtype);
        vacationtypeSearchRepository.save(result);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, vacationtype.getId().toString()))
            .body(result);
    }

    /**
     * GET  /vacationtypes : get all the vacationtypes.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of vacationtypes in body
     */
    @GetMapping("/vacationtypes")
    @Timed
    public ResponseEntity<List<Vacationtype>> getAllVacationtypes(Pageable pageable) {
        log.debug("REST request to get a page of Vacationtypes");
        Page<Vacationtype> page = vacationtypeRepository.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/vacationtypes");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /vacationtypes/:id : get the "id" vacationtype.
     *
     * @param id the id of the vacationtype to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the vacationtype, or with status 404 (Not Found)
     */
    @GetMapping("/vacationtypes/{id}")
    @Timed
    public ResponseEntity<Vacationtype> getVacationtype(@PathVariable Long id) {
        log.debug("REST request to get Vacationtype : {}", id);
        Optional<Vacationtype> vacationtype = vacationtypeRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(vacationtype);
    }

    /**
     * DELETE  /vacationtypes/:id : delete the "id" vacationtype.
     *
     * @param id the id of the vacationtype to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/vacationtypes/{id}")
    @Timed
    public ResponseEntity<Void> deleteVacationtype(@PathVariable Long id) {
        log.debug("REST request to delete Vacationtype : {}", id);

        vacationtypeRepository.deleteById(id);
        vacationtypeSearchRepository.deleteById(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    /**
     * SEARCH  /_search/vacationtypes?query=:query : search for the vacationtype corresponding
     * to the query.
     *
     * @param query the query of the vacationtype search
     * @param pageable the pagination information
     * @return the result of the search
     */
    @GetMapping("/_search/vacationtypes")
    @Timed
    public ResponseEntity<List<Vacationtype>> searchVacationtypes(@RequestParam String query, Pageable pageable) {
        log.debug("REST request to search for a page of Vacationtypes for query {}", query);
        Page<Vacationtype> page = vacationtypeSearchRepository.search(queryStringQuery(query), pageable);
        HttpHeaders headers = PaginationUtil.generateSearchPaginationHttpHeaders(query, page, "/api/_search/vacationtypes");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

}
