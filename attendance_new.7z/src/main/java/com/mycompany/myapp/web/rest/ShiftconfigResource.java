package com.mycompany.myapp.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.mycompany.myapp.domain.Shiftconfig;
import com.mycompany.myapp.repository.ShiftconfigRepository;
import com.mycompany.myapp.repository.search.ShiftconfigSearchRepository;
import com.mycompany.myapp.web.rest.errors.BadRequestAlertException;
import com.mycompany.myapp.web.rest.util.HeaderUtil;
import com.mycompany.myapp.web.rest.util.PaginationUtil;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import static org.elasticsearch.index.query.QueryBuilders.*;

/**
 * REST controller for managing Shiftconfig.
 */
@RestController
@RequestMapping("/api")
public class ShiftconfigResource {

    private final Logger log = LoggerFactory.getLogger(ShiftconfigResource.class);

    private static final String ENTITY_NAME = "shiftconfig";

    private final ShiftconfigRepository shiftconfigRepository;

    private final ShiftconfigSearchRepository shiftconfigSearchRepository;

    public ShiftconfigResource(ShiftconfigRepository shiftconfigRepository, ShiftconfigSearchRepository shiftconfigSearchRepository) {
        this.shiftconfigRepository = shiftconfigRepository;
        this.shiftconfigSearchRepository = shiftconfigSearchRepository;
    }

    /**
     * POST  /shiftconfigs : Create a new shiftconfig.
     *
     * @param shiftconfig the shiftconfig to create
     * @return the ResponseEntity with status 201 (Created) and with body the new shiftconfig, or with status 400 (Bad Request) if the shiftconfig has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/shiftconfigs")
    @Timed
    public ResponseEntity<Shiftconfig> createShiftconfig(@Valid @RequestBody Shiftconfig shiftconfig) throws URISyntaxException {
        log.debug("REST request to save Shiftconfig : {}", shiftconfig);
        if (shiftconfig.getId() != null) {
            throw new BadRequestAlertException("A new shiftconfig cannot already have an ID", ENTITY_NAME, "idexists");
        }
        Shiftconfig result = shiftconfigRepository.save(shiftconfig);
        shiftconfigSearchRepository.save(result);
        return ResponseEntity.created(new URI("/api/shiftconfigs/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /shiftconfigs : Updates an existing shiftconfig.
     *
     * @param shiftconfig the shiftconfig to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated shiftconfig,
     * or with status 400 (Bad Request) if the shiftconfig is not valid,
     * or with status 500 (Internal Server Error) if the shiftconfig couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/shiftconfigs")
    @Timed
    public ResponseEntity<Shiftconfig> updateShiftconfig(@Valid @RequestBody Shiftconfig shiftconfig) throws URISyntaxException {
        log.debug("REST request to update Shiftconfig : {}", shiftconfig);
        if (shiftconfig.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        Shiftconfig result = shiftconfigRepository.save(shiftconfig);
        shiftconfigSearchRepository.save(result);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, shiftconfig.getId().toString()))
            .body(result);
    }

    /**
     * GET  /shiftconfigs : get all the shiftconfigs.
     *
     * @param pageable the pagination information
     * @return the ResponseEntity with status 200 (OK) and the list of shiftconfigs in body
     */
    @GetMapping("/shiftconfigs")
    @Timed
    public ResponseEntity<List<Shiftconfig>> getAllShiftconfigs(Pageable pageable) {
        log.debug("REST request to get a page of Shiftconfigs");
        Page<Shiftconfig> page = shiftconfigRepository.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(page, "/api/shiftconfigs");
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * GET  /shiftconfigs/:id : get the "id" shiftconfig.
     *
     * @param id the id of the shiftconfig to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the shiftconfig, or with status 404 (Not Found)
     */
    @GetMapping("/shiftconfigs/{id}")
    @Timed
    public ResponseEntity<Shiftconfig> getShiftconfig(@PathVariable Long id) {
        log.debug("REST request to get Shiftconfig : {}", id);
        Optional<Shiftconfig> shiftconfig = shiftconfigRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(shiftconfig);
    }

    /**
     * DELETE  /shiftconfigs/:id : delete the "id" shiftconfig.
     *
     * @param id the id of the shiftconfig to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/shiftconfigs/{id}")
    @Timed
    public ResponseEntity<Void> deleteShiftconfig(@PathVariable Long id) {
        log.debug("REST request to delete Shiftconfig : {}", id);

        shiftconfigRepository.deleteById(id);
        shiftconfigSearchRepository.deleteById(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id.toString())).build();
    }

    /**
     * SEARCH  /_search/shiftconfigs?query=:query : search for the shiftconfig corresponding
     * to the query.
     *
     * @param query the query of the shiftconfig search
     * @param pageable the pagination information
     * @return the result of the search
     */
    @GetMapping("/_search/shiftconfigs")
    @Timed
    public ResponseEntity<List<Shiftconfig>> searchShiftconfigs(@RequestParam String query, Pageable pageable) {
        log.debug("REST request to search for a page of Shiftconfigs for query {}", query);
        Page<Shiftconfig> page = shiftconfigSearchRepository.search(queryStringQuery(query), pageable);
        HttpHeaders headers = PaginationUtil.generateSearchPaginationHttpHeaders(query, page, "/api/_search/shiftconfigs");
        return new ResponseEntity<>(page.getContent(), headers, HttpStatus.OK);
    }

}
