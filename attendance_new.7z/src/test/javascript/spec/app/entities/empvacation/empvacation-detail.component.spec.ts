/* tslint:disable max-line-length */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { JhipTestModule } from '../../../test.module';
import { EmpvacationDetailComponent } from 'app/entities/empvacation/empvacation-detail.component';
import { Empvacation } from 'app/shared/model/empvacation.model';

describe('Component Tests', () => {
    describe('Empvacation Management Detail Component', () => {
        let comp: EmpvacationDetailComponent;
        let fixture: ComponentFixture<EmpvacationDetailComponent>;
        const route = ({ data: of({ empvacation: new Empvacation(123) }) } as any) as ActivatedRoute;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [JhipTestModule],
                declarations: [EmpvacationDetailComponent],
                providers: [{ provide: ActivatedRoute, useValue: route }]
            })
                .overrideTemplate(EmpvacationDetailComponent, '')
                .compileComponents();
            fixture = TestBed.createComponent(EmpvacationDetailComponent);
            comp = fixture.componentInstance;
        });

        describe('OnInit', () => {
            it('Should call load all on init', () => {
                // GIVEN

                // WHEN
                comp.ngOnInit();

                // THEN
                expect(comp.empvacation).toEqual(jasmine.objectContaining({ id: 123 }));
            });
        });
    });
});
