/* tslint:disable max-line-length */
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpResponse } from '@angular/common/http';
import { Observable, of } from 'rxjs';

import { JhipTestModule } from '../../../test.module';
import { EmpvacationUpdateComponent } from 'app/entities/empvacation/empvacation-update.component';
import { EmpvacationService } from 'app/entities/empvacation/empvacation.service';
import { Empvacation } from 'app/shared/model/empvacation.model';

describe('Component Tests', () => {
    describe('Empvacation Management Update Component', () => {
        let comp: EmpvacationUpdateComponent;
        let fixture: ComponentFixture<EmpvacationUpdateComponent>;
        let service: EmpvacationService;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [JhipTestModule],
                declarations: [EmpvacationUpdateComponent]
            })
                .overrideTemplate(EmpvacationUpdateComponent, '')
                .compileComponents();

            fixture = TestBed.createComponent(EmpvacationUpdateComponent);
            comp = fixture.componentInstance;
            service = fixture.debugElement.injector.get(EmpvacationService);
        });

        describe('save', () => {
            it('Should call update service on save for existing entity', fakeAsync(() => {
                // GIVEN
                const entity = new Empvacation(123);
                spyOn(service, 'update').and.returnValue(of(new HttpResponse({ body: entity })));
                comp.empvacation = entity;
                // WHEN
                comp.save();
                tick(); // simulate async

                // THEN
                expect(service.update).toHaveBeenCalledWith(entity);
                expect(comp.isSaving).toEqual(false);
            }));

            it('Should call create service on save for new entity', fakeAsync(() => {
                // GIVEN
                const entity = new Empvacation();
                spyOn(service, 'create').and.returnValue(of(new HttpResponse({ body: entity })));
                comp.empvacation = entity;
                // WHEN
                comp.save();
                tick(); // simulate async

                // THEN
                expect(service.create).toHaveBeenCalledWith(entity);
                expect(comp.isSaving).toEqual(false);
            }));
        });
    });
});
