/* tslint:disable max-line-length */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { JhipTestModule } from '../../../test.module';
import { ShiftconfigDetailComponent } from 'app/entities/shiftconfig/shiftconfig-detail.component';
import { Shiftconfig } from 'app/shared/model/shiftconfig.model';

describe('Component Tests', () => {
    describe('Shiftconfig Management Detail Component', () => {
        let comp: ShiftconfigDetailComponent;
        let fixture: ComponentFixture<ShiftconfigDetailComponent>;
        const route = ({ data: of({ shiftconfig: new Shiftconfig(123) }) } as any) as ActivatedRoute;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [JhipTestModule],
                declarations: [ShiftconfigDetailComponent],
                providers: [{ provide: ActivatedRoute, useValue: route }]
            })
                .overrideTemplate(ShiftconfigDetailComponent, '')
                .compileComponents();
            fixture = TestBed.createComponent(ShiftconfigDetailComponent);
            comp = fixture.componentInstance;
        });

        describe('OnInit', () => {
            it('Should call load all on init', () => {
                // GIVEN

                // WHEN
                comp.ngOnInit();

                // THEN
                expect(comp.shiftconfig).toEqual(jasmine.objectContaining({ id: 123 }));
            });
        });
    });
});
