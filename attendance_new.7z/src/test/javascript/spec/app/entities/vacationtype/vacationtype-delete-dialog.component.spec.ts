/* tslint:disable max-line-length */
import { ComponentFixture, TestBed, inject, fakeAsync, tick } from '@angular/core/testing';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable, of } from 'rxjs';
import { JhiEventManager } from 'ng-jhipster';

import { JhipTestModule } from '../../../test.module';
import { VacationtypeDeleteDialogComponent } from 'app/entities/vacationtype/vacationtype-delete-dialog.component';
import { VacationtypeService } from 'app/entities/vacationtype/vacationtype.service';

describe('Component Tests', () => {
    describe('Vacationtype Management Delete Component', () => {
        let comp: VacationtypeDeleteDialogComponent;
        let fixture: ComponentFixture<VacationtypeDeleteDialogComponent>;
        let service: VacationtypeService;
        let mockEventManager: any;
        let mockActiveModal: any;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [JhipTestModule],
                declarations: [VacationtypeDeleteDialogComponent]
            })
                .overrideTemplate(VacationtypeDeleteDialogComponent, '')
                .compileComponents();
            fixture = TestBed.createComponent(VacationtypeDeleteDialogComponent);
            comp = fixture.componentInstance;
            service = fixture.debugElement.injector.get(VacationtypeService);
            mockEventManager = fixture.debugElement.injector.get(JhiEventManager);
            mockActiveModal = fixture.debugElement.injector.get(NgbActiveModal);
        });

        describe('confirmDelete', () => {
            it('Should call delete service on confirmDelete', inject(
                [],
                fakeAsync(() => {
                    // GIVEN
                    spyOn(service, 'delete').and.returnValue(of({}));

                    // WHEN
                    comp.confirmDelete(123);
                    tick();

                    // THEN
                    expect(service.delete).toHaveBeenCalledWith(123);
                    expect(mockActiveModal.dismissSpy).toHaveBeenCalled();
                    expect(mockEventManager.broadcastSpy).toHaveBeenCalled();
                })
            ));
        });
    });
});
