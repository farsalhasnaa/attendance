/* tslint:disable max-line-length */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { of } from 'rxjs';

import { JhipTestModule } from '../../../test.module';
import { VacationtypeDetailComponent } from 'app/entities/vacationtype/vacationtype-detail.component';
import { Vacationtype } from 'app/shared/model/vacationtype.model';

describe('Component Tests', () => {
    describe('Vacationtype Management Detail Component', () => {
        let comp: VacationtypeDetailComponent;
        let fixture: ComponentFixture<VacationtypeDetailComponent>;
        const route = ({ data: of({ vacationtype: new Vacationtype(123) }) } as any) as ActivatedRoute;

        beforeEach(() => {
            TestBed.configureTestingModule({
                imports: [JhipTestModule],
                declarations: [VacationtypeDetailComponent],
                providers: [{ provide: ActivatedRoute, useValue: route }]
            })
                .overrideTemplate(VacationtypeDetailComponent, '')
                .compileComponents();
            fixture = TestBed.createComponent(VacationtypeDetailComponent);
            comp = fixture.componentInstance;
        });

        describe('OnInit', () => {
            it('Should call load all on init', () => {
                // GIVEN

                // WHEN
                comp.ngOnInit();

                // THEN
                expect(comp.vacationtype).toEqual(jasmine.objectContaining({ id: 123 }));
            });
        });
    });
});
