package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.JhipApp;

import com.mycompany.myapp.domain.Attendance;
import com.mycompany.myapp.domain.Employee;
import com.mycompany.myapp.repository.AttendanceRepository;
import com.mycompany.myapp.repository.search.AttendanceSearchRepository;
import com.mycompany.myapp.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.ZoneOffset;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;


import static com.mycompany.myapp.web.rest.TestUtil.sameInstant;
import static com.mycompany.myapp.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the AttendanceResource REST controller.
 *
 * @see AttendanceResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = JhipApp.class)
public class AttendanceResourceIntTest {

    private static final ZonedDateTime DEFAULT_ENTRYTIME = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_ENTRYTIME = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_EXITTIME = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_EXITTIME = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final Boolean DEFAULT_ATTEND = false;
    private static final Boolean UPDATED_ATTEND = true;

    private static final String DEFAULT_NOTE = "AAAAAAAAAA";
    private static final String UPDATED_NOTE = "BBBBBBBBBB";

    private static final Long DEFAULT_WORKINGHOURS = 1L;
    private static final Long UPDATED_WORKINGHOURS = 2L;

    private static final Long DEFAULT_LATEHOURS = 1L;
    private static final Long UPDATED_LATEHOURS = 2L;

    private static final Long DEFAULT_PERMISSIONHOURS = 1L;
    private static final Long UPDATED_PERMISSIONHOURS = 2L;

    private static final Long DEFAULT_TOTALHOURS = 1L;
    private static final Long UPDATED_TOTALHOURS = 2L;

    private static final Boolean DEFAULT_EXITCONFIRMATION = false;
    private static final Boolean UPDATED_EXITCONFIRMATION = true;

    @Autowired
    private AttendanceRepository attendanceRepository;

    /**
     * This repository is mocked in the com.mycompany.myapp.repository.search test package.
     *
     * @see com.mycompany.myapp.repository.search.AttendanceSearchRepositoryMockConfiguration
     */
    @Autowired
    private AttendanceSearchRepository mockAttendanceSearchRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restAttendanceMockMvc;

    private Attendance attendance;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final AttendanceResource attendanceResource = new AttendanceResource(attendanceRepository, mockAttendanceSearchRepository);
        this.restAttendanceMockMvc = MockMvcBuilders.standaloneSetup(attendanceResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Attendance createEntity(EntityManager em) {
        Attendance attendance = new Attendance()
            .entrytime(DEFAULT_ENTRYTIME)
            .exittime(DEFAULT_EXITTIME)
            .attend(DEFAULT_ATTEND)
            .note(DEFAULT_NOTE)
            .workinghours(DEFAULT_WORKINGHOURS)
            .latehours(DEFAULT_LATEHOURS)
            .permissionhours(DEFAULT_PERMISSIONHOURS)
            .totalhours(DEFAULT_TOTALHOURS)
            .exitconfirmation(DEFAULT_EXITCONFIRMATION);
        // Add required entity
        Employee employee = EmployeeResourceIntTest.createEntity(em);
        em.persist(employee);
        em.flush();
        attendance.setEmployee(employee);
        return attendance;
    }

    @Before
    public void initTest() {
        attendance = createEntity(em);
    }

    @Test
    @Transactional
    public void createAttendance() throws Exception {
        int databaseSizeBeforeCreate = attendanceRepository.findAll().size();

        // Create the Attendance
        restAttendanceMockMvc.perform(post("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isCreated());

        // Validate the Attendance in the database
        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeCreate + 1);
        Attendance testAttendance = attendanceList.get(attendanceList.size() - 1);
        assertThat(testAttendance.getEntrytime()).isEqualTo(DEFAULT_ENTRYTIME);
        assertThat(testAttendance.getExittime()).isEqualTo(DEFAULT_EXITTIME);
        assertThat(testAttendance.isAttend()).isEqualTo(DEFAULT_ATTEND);
        assertThat(testAttendance.getNote()).isEqualTo(DEFAULT_NOTE);
        assertThat(testAttendance.getWorkinghours()).isEqualTo(DEFAULT_WORKINGHOURS);
        assertThat(testAttendance.getLatehours()).isEqualTo(DEFAULT_LATEHOURS);
        assertThat(testAttendance.getPermissionhours()).isEqualTo(DEFAULT_PERMISSIONHOURS);
        assertThat(testAttendance.getTotalhours()).isEqualTo(DEFAULT_TOTALHOURS);
        assertThat(testAttendance.isExitconfirmation()).isEqualTo(DEFAULT_EXITCONFIRMATION);

        // Validate the Attendance in Elasticsearch
        verify(mockAttendanceSearchRepository, times(1)).save(testAttendance);
    }

    @Test
    @Transactional
    public void createAttendanceWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = attendanceRepository.findAll().size();

        // Create the Attendance with an existing ID
        attendance.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restAttendanceMockMvc.perform(post("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isBadRequest());

        // Validate the Attendance in the database
        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeCreate);

        // Validate the Attendance in Elasticsearch
        verify(mockAttendanceSearchRepository, times(0)).save(attendance);
    }

    @Test
    @Transactional
    public void checkEntrytimeIsRequired() throws Exception {
        int databaseSizeBeforeTest = attendanceRepository.findAll().size();
        // set the field null
        attendance.setEntrytime(null);

        // Create the Attendance, which fails.

        restAttendanceMockMvc.perform(post("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isBadRequest());

        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkExittimeIsRequired() throws Exception {
        int databaseSizeBeforeTest = attendanceRepository.findAll().size();
        // set the field null
        attendance.setExittime(null);

        // Create the Attendance, which fails.

        restAttendanceMockMvc.perform(post("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isBadRequest());

        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkAttendIsRequired() throws Exception {
        int databaseSizeBeforeTest = attendanceRepository.findAll().size();
        // set the field null
        attendance.setAttend(null);

        // Create the Attendance, which fails.

        restAttendanceMockMvc.perform(post("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isBadRequest());

        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllAttendances() throws Exception {
        // Initialize the database
        attendanceRepository.saveAndFlush(attendance);

        // Get all the attendanceList
        restAttendanceMockMvc.perform(get("/api/attendances?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(attendance.getId().intValue())))
            .andExpect(jsonPath("$.[*].entrytime").value(hasItem(sameInstant(DEFAULT_ENTRYTIME))))
            .andExpect(jsonPath("$.[*].exittime").value(hasItem(sameInstant(DEFAULT_EXITTIME))))
            .andExpect(jsonPath("$.[*].attend").value(hasItem(DEFAULT_ATTEND.booleanValue())))
            .andExpect(jsonPath("$.[*].note").value(hasItem(DEFAULT_NOTE.toString())))
            .andExpect(jsonPath("$.[*].workinghours").value(hasItem(DEFAULT_WORKINGHOURS.intValue())))
            .andExpect(jsonPath("$.[*].latehours").value(hasItem(DEFAULT_LATEHOURS.intValue())))
            .andExpect(jsonPath("$.[*].permissionhours").value(hasItem(DEFAULT_PERMISSIONHOURS.intValue())))
            .andExpect(jsonPath("$.[*].totalhours").value(hasItem(DEFAULT_TOTALHOURS.intValue())))
            .andExpect(jsonPath("$.[*].exitconfirmation").value(hasItem(DEFAULT_EXITCONFIRMATION.booleanValue())));
    }
    
    @Test
    @Transactional
    public void getAttendance() throws Exception {
        // Initialize the database
        attendanceRepository.saveAndFlush(attendance);

        // Get the attendance
        restAttendanceMockMvc.perform(get("/api/attendances/{id}", attendance.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(attendance.getId().intValue()))
            .andExpect(jsonPath("$.entrytime").value(sameInstant(DEFAULT_ENTRYTIME)))
            .andExpect(jsonPath("$.exittime").value(sameInstant(DEFAULT_EXITTIME)))
            .andExpect(jsonPath("$.attend").value(DEFAULT_ATTEND.booleanValue()))
            .andExpect(jsonPath("$.note").value(DEFAULT_NOTE.toString()))
            .andExpect(jsonPath("$.workinghours").value(DEFAULT_WORKINGHOURS.intValue()))
            .andExpect(jsonPath("$.latehours").value(DEFAULT_LATEHOURS.intValue()))
            .andExpect(jsonPath("$.permissionhours").value(DEFAULT_PERMISSIONHOURS.intValue()))
            .andExpect(jsonPath("$.totalhours").value(DEFAULT_TOTALHOURS.intValue()))
            .andExpect(jsonPath("$.exitconfirmation").value(DEFAULT_EXITCONFIRMATION.booleanValue()));
    }

    @Test
    @Transactional
    public void getNonExistingAttendance() throws Exception {
        // Get the attendance
        restAttendanceMockMvc.perform(get("/api/attendances/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateAttendance() throws Exception {
        // Initialize the database
        attendanceRepository.saveAndFlush(attendance);

        int databaseSizeBeforeUpdate = attendanceRepository.findAll().size();

        // Update the attendance
        Attendance updatedAttendance = attendanceRepository.findById(attendance.getId()).get();
        // Disconnect from session so that the updates on updatedAttendance are not directly saved in db
        em.detach(updatedAttendance);
        updatedAttendance
            .entrytime(UPDATED_ENTRYTIME)
            .exittime(UPDATED_EXITTIME)
            .attend(UPDATED_ATTEND)
            .note(UPDATED_NOTE)
            .workinghours(UPDATED_WORKINGHOURS)
            .latehours(UPDATED_LATEHOURS)
            .permissionhours(UPDATED_PERMISSIONHOURS)
            .totalhours(UPDATED_TOTALHOURS)
            .exitconfirmation(UPDATED_EXITCONFIRMATION);

        restAttendanceMockMvc.perform(put("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedAttendance)))
            .andExpect(status().isOk());

        // Validate the Attendance in the database
        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeUpdate);
        Attendance testAttendance = attendanceList.get(attendanceList.size() - 1);
        assertThat(testAttendance.getEntrytime()).isEqualTo(UPDATED_ENTRYTIME);
        assertThat(testAttendance.getExittime()).isEqualTo(UPDATED_EXITTIME);
        assertThat(testAttendance.isAttend()).isEqualTo(UPDATED_ATTEND);
        assertThat(testAttendance.getNote()).isEqualTo(UPDATED_NOTE);
        assertThat(testAttendance.getWorkinghours()).isEqualTo(UPDATED_WORKINGHOURS);
        assertThat(testAttendance.getLatehours()).isEqualTo(UPDATED_LATEHOURS);
        assertThat(testAttendance.getPermissionhours()).isEqualTo(UPDATED_PERMISSIONHOURS);
        assertThat(testAttendance.getTotalhours()).isEqualTo(UPDATED_TOTALHOURS);
        assertThat(testAttendance.isExitconfirmation()).isEqualTo(UPDATED_EXITCONFIRMATION);

        // Validate the Attendance in Elasticsearch
        verify(mockAttendanceSearchRepository, times(1)).save(testAttendance);
    }

    @Test
    @Transactional
    public void updateNonExistingAttendance() throws Exception {
        int databaseSizeBeforeUpdate = attendanceRepository.findAll().size();

        // Create the Attendance

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAttendanceMockMvc.perform(put("/api/attendances")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(attendance)))
            .andExpect(status().isBadRequest());

        // Validate the Attendance in the database
        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Attendance in Elasticsearch
        verify(mockAttendanceSearchRepository, times(0)).save(attendance);
    }

    @Test
    @Transactional
    public void deleteAttendance() throws Exception {
        // Initialize the database
        attendanceRepository.saveAndFlush(attendance);

        int databaseSizeBeforeDelete = attendanceRepository.findAll().size();

        // Get the attendance
        restAttendanceMockMvc.perform(delete("/api/attendances/{id}", attendance.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Attendance> attendanceList = attendanceRepository.findAll();
        assertThat(attendanceList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Attendance in Elasticsearch
        verify(mockAttendanceSearchRepository, times(1)).deleteById(attendance.getId());
    }

    @Test
    @Transactional
    public void searchAttendance() throws Exception {
        // Initialize the database
        attendanceRepository.saveAndFlush(attendance);
        when(mockAttendanceSearchRepository.search(queryStringQuery("id:" + attendance.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(attendance), PageRequest.of(0, 1), 1));
        // Search the attendance
        restAttendanceMockMvc.perform(get("/api/_search/attendances?query=id:" + attendance.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(attendance.getId().intValue())))
            .andExpect(jsonPath("$.[*].entrytime").value(hasItem(sameInstant(DEFAULT_ENTRYTIME))))
            .andExpect(jsonPath("$.[*].exittime").value(hasItem(sameInstant(DEFAULT_EXITTIME))))
            .andExpect(jsonPath("$.[*].attend").value(hasItem(DEFAULT_ATTEND.booleanValue())))
            .andExpect(jsonPath("$.[*].note").value(hasItem(DEFAULT_NOTE)))
            .andExpect(jsonPath("$.[*].workinghours").value(hasItem(DEFAULT_WORKINGHOURS.intValue())))
            .andExpect(jsonPath("$.[*].latehours").value(hasItem(DEFAULT_LATEHOURS.intValue())))
            .andExpect(jsonPath("$.[*].permissionhours").value(hasItem(DEFAULT_PERMISSIONHOURS.intValue())))
            .andExpect(jsonPath("$.[*].totalhours").value(hasItem(DEFAULT_TOTALHOURS.intValue())))
            .andExpect(jsonPath("$.[*].exitconfirmation").value(hasItem(DEFAULT_EXITCONFIRMATION.booleanValue())));
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Attendance.class);
        Attendance attendance1 = new Attendance();
        attendance1.setId(1L);
        Attendance attendance2 = new Attendance();
        attendance2.setId(attendance1.getId());
        assertThat(attendance1).isEqualTo(attendance2);
        attendance2.setId(2L);
        assertThat(attendance1).isNotEqualTo(attendance2);
        attendance1.setId(null);
        assertThat(attendance1).isNotEqualTo(attendance2);
    }
}
