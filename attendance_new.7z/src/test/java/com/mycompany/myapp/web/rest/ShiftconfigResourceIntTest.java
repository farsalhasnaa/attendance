package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.JhipApp;

import com.mycompany.myapp.domain.Shiftconfig;
import com.mycompany.myapp.repository.ShiftconfigRepository;
import com.mycompany.myapp.repository.search.ShiftconfigSearchRepository;
import com.mycompany.myapp.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.ZoneOffset;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;


import static com.mycompany.myapp.web.rest.TestUtil.sameInstant;
import static com.mycompany.myapp.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ShiftconfigResource REST controller.
 *
 * @see ShiftconfigResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = JhipApp.class)
public class ShiftconfigResourceIntTest {

    private static final String DEFAULT_SHIFTNAME = "AAAAAAAAAA";
    private static final String UPDATED_SHIFTNAME = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SHIFTSTART = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_SHIFTSTART = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_SHIFTEND = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_SHIFTEND = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    @Autowired
    private ShiftconfigRepository shiftconfigRepository;

    /**
     * This repository is mocked in the com.mycompany.myapp.repository.search test package.
     *
     * @see com.mycompany.myapp.repository.search.ShiftconfigSearchRepositoryMockConfiguration
     */
    @Autowired
    private ShiftconfigSearchRepository mockShiftconfigSearchRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restShiftconfigMockMvc;

    private Shiftconfig shiftconfig;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final ShiftconfigResource shiftconfigResource = new ShiftconfigResource(shiftconfigRepository, mockShiftconfigSearchRepository);
        this.restShiftconfigMockMvc = MockMvcBuilders.standaloneSetup(shiftconfigResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Shiftconfig createEntity(EntityManager em) {
        Shiftconfig shiftconfig = new Shiftconfig()
            .shiftname(DEFAULT_SHIFTNAME)
            .shiftstart(DEFAULT_SHIFTSTART)
            .shiftend(DEFAULT_SHIFTEND);
        return shiftconfig;
    }

    @Before
    public void initTest() {
        shiftconfig = createEntity(em);
    }

    @Test
    @Transactional
    public void createShiftconfig() throws Exception {
        int databaseSizeBeforeCreate = shiftconfigRepository.findAll().size();

        // Create the Shiftconfig
        restShiftconfigMockMvc.perform(post("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isCreated());

        // Validate the Shiftconfig in the database
        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeCreate + 1);
        Shiftconfig testShiftconfig = shiftconfigList.get(shiftconfigList.size() - 1);
        assertThat(testShiftconfig.getShiftname()).isEqualTo(DEFAULT_SHIFTNAME);
        assertThat(testShiftconfig.getShiftstart()).isEqualTo(DEFAULT_SHIFTSTART);
        assertThat(testShiftconfig.getShiftend()).isEqualTo(DEFAULT_SHIFTEND);

        // Validate the Shiftconfig in Elasticsearch
        verify(mockShiftconfigSearchRepository, times(1)).save(testShiftconfig);
    }

    @Test
    @Transactional
    public void createShiftconfigWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = shiftconfigRepository.findAll().size();

        // Create the Shiftconfig with an existing ID
        shiftconfig.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restShiftconfigMockMvc.perform(post("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isBadRequest());

        // Validate the Shiftconfig in the database
        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeCreate);

        // Validate the Shiftconfig in Elasticsearch
        verify(mockShiftconfigSearchRepository, times(0)).save(shiftconfig);
    }

    @Test
    @Transactional
    public void checkShiftnameIsRequired() throws Exception {
        int databaseSizeBeforeTest = shiftconfigRepository.findAll().size();
        // set the field null
        shiftconfig.setShiftname(null);

        // Create the Shiftconfig, which fails.

        restShiftconfigMockMvc.perform(post("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isBadRequest());

        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkShiftstartIsRequired() throws Exception {
        int databaseSizeBeforeTest = shiftconfigRepository.findAll().size();
        // set the field null
        shiftconfig.setShiftstart(null);

        // Create the Shiftconfig, which fails.

        restShiftconfigMockMvc.perform(post("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isBadRequest());

        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkShiftendIsRequired() throws Exception {
        int databaseSizeBeforeTest = shiftconfigRepository.findAll().size();
        // set the field null
        shiftconfig.setShiftend(null);

        // Create the Shiftconfig, which fails.

        restShiftconfigMockMvc.perform(post("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isBadRequest());

        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllShiftconfigs() throws Exception {
        // Initialize the database
        shiftconfigRepository.saveAndFlush(shiftconfig);

        // Get all the shiftconfigList
        restShiftconfigMockMvc.perform(get("/api/shiftconfigs?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(shiftconfig.getId().intValue())))
            .andExpect(jsonPath("$.[*].shiftname").value(hasItem(DEFAULT_SHIFTNAME.toString())))
            .andExpect(jsonPath("$.[*].shiftstart").value(hasItem(sameInstant(DEFAULT_SHIFTSTART))))
            .andExpect(jsonPath("$.[*].shiftend").value(hasItem(sameInstant(DEFAULT_SHIFTEND))));
    }
    
    @Test
    @Transactional
    public void getShiftconfig() throws Exception {
        // Initialize the database
        shiftconfigRepository.saveAndFlush(shiftconfig);

        // Get the shiftconfig
        restShiftconfigMockMvc.perform(get("/api/shiftconfigs/{id}", shiftconfig.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(shiftconfig.getId().intValue()))
            .andExpect(jsonPath("$.shiftname").value(DEFAULT_SHIFTNAME.toString()))
            .andExpect(jsonPath("$.shiftstart").value(sameInstant(DEFAULT_SHIFTSTART)))
            .andExpect(jsonPath("$.shiftend").value(sameInstant(DEFAULT_SHIFTEND)));
    }

    @Test
    @Transactional
    public void getNonExistingShiftconfig() throws Exception {
        // Get the shiftconfig
        restShiftconfigMockMvc.perform(get("/api/shiftconfigs/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateShiftconfig() throws Exception {
        // Initialize the database
        shiftconfigRepository.saveAndFlush(shiftconfig);

        int databaseSizeBeforeUpdate = shiftconfigRepository.findAll().size();

        // Update the shiftconfig
        Shiftconfig updatedShiftconfig = shiftconfigRepository.findById(shiftconfig.getId()).get();
        // Disconnect from session so that the updates on updatedShiftconfig are not directly saved in db
        em.detach(updatedShiftconfig);
        updatedShiftconfig
            .shiftname(UPDATED_SHIFTNAME)
            .shiftstart(UPDATED_SHIFTSTART)
            .shiftend(UPDATED_SHIFTEND);

        restShiftconfigMockMvc.perform(put("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedShiftconfig)))
            .andExpect(status().isOk());

        // Validate the Shiftconfig in the database
        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeUpdate);
        Shiftconfig testShiftconfig = shiftconfigList.get(shiftconfigList.size() - 1);
        assertThat(testShiftconfig.getShiftname()).isEqualTo(UPDATED_SHIFTNAME);
        assertThat(testShiftconfig.getShiftstart()).isEqualTo(UPDATED_SHIFTSTART);
        assertThat(testShiftconfig.getShiftend()).isEqualTo(UPDATED_SHIFTEND);

        // Validate the Shiftconfig in Elasticsearch
        verify(mockShiftconfigSearchRepository, times(1)).save(testShiftconfig);
    }

    @Test
    @Transactional
    public void updateNonExistingShiftconfig() throws Exception {
        int databaseSizeBeforeUpdate = shiftconfigRepository.findAll().size();

        // Create the Shiftconfig

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restShiftconfigMockMvc.perform(put("/api/shiftconfigs")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(shiftconfig)))
            .andExpect(status().isBadRequest());

        // Validate the Shiftconfig in the database
        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Shiftconfig in Elasticsearch
        verify(mockShiftconfigSearchRepository, times(0)).save(shiftconfig);
    }

    @Test
    @Transactional
    public void deleteShiftconfig() throws Exception {
        // Initialize the database
        shiftconfigRepository.saveAndFlush(shiftconfig);

        int databaseSizeBeforeDelete = shiftconfigRepository.findAll().size();

        // Get the shiftconfig
        restShiftconfigMockMvc.perform(delete("/api/shiftconfigs/{id}", shiftconfig.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Shiftconfig> shiftconfigList = shiftconfigRepository.findAll();
        assertThat(shiftconfigList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Shiftconfig in Elasticsearch
        verify(mockShiftconfigSearchRepository, times(1)).deleteById(shiftconfig.getId());
    }

    @Test
    @Transactional
    public void searchShiftconfig() throws Exception {
        // Initialize the database
        shiftconfigRepository.saveAndFlush(shiftconfig);
        when(mockShiftconfigSearchRepository.search(queryStringQuery("id:" + shiftconfig.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(shiftconfig), PageRequest.of(0, 1), 1));
        // Search the shiftconfig
        restShiftconfigMockMvc.perform(get("/api/_search/shiftconfigs?query=id:" + shiftconfig.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(shiftconfig.getId().intValue())))
            .andExpect(jsonPath("$.[*].shiftname").value(hasItem(DEFAULT_SHIFTNAME)))
            .andExpect(jsonPath("$.[*].shiftstart").value(hasItem(sameInstant(DEFAULT_SHIFTSTART))))
            .andExpect(jsonPath("$.[*].shiftend").value(hasItem(sameInstant(DEFAULT_SHIFTEND))));
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Shiftconfig.class);
        Shiftconfig shiftconfig1 = new Shiftconfig();
        shiftconfig1.setId(1L);
        Shiftconfig shiftconfig2 = new Shiftconfig();
        shiftconfig2.setId(shiftconfig1.getId());
        assertThat(shiftconfig1).isEqualTo(shiftconfig2);
        shiftconfig2.setId(2L);
        assertThat(shiftconfig1).isNotEqualTo(shiftconfig2);
        shiftconfig1.setId(null);
        assertThat(shiftconfig1).isNotEqualTo(shiftconfig2);
    }
}
