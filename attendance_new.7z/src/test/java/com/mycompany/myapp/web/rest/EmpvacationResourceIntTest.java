package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.JhipApp;

import com.mycompany.myapp.domain.Empvacation;
import com.mycompany.myapp.domain.Employee;
import com.mycompany.myapp.domain.Vacationtype;
import com.mycompany.myapp.repository.EmpvacationRepository;
import com.mycompany.myapp.repository.search.EmpvacationSearchRepository;
import com.mycompany.myapp.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.ZoneOffset;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;


import static com.mycompany.myapp.web.rest.TestUtil.sameInstant;
import static com.mycompany.myapp.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the EmpvacationResource REST controller.
 *
 * @see EmpvacationResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = JhipApp.class)
public class EmpvacationResourceIntTest {

    private static final ZonedDateTime DEFAULT_STARTDATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_STARTDATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_ENDDATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_ENDDATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    @Autowired
    private EmpvacationRepository empvacationRepository;

    /**
     * This repository is mocked in the com.mycompany.myapp.repository.search test package.
     *
     * @see com.mycompany.myapp.repository.search.EmpvacationSearchRepositoryMockConfiguration
     */
    @Autowired
    private EmpvacationSearchRepository mockEmpvacationSearchRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restEmpvacationMockMvc;

    private Empvacation empvacation;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final EmpvacationResource empvacationResource = new EmpvacationResource(empvacationRepository, mockEmpvacationSearchRepository);
        this.restEmpvacationMockMvc = MockMvcBuilders.standaloneSetup(empvacationResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Empvacation createEntity(EntityManager em) {
        Empvacation empvacation = new Empvacation()
            .startdate(DEFAULT_STARTDATE)
            .enddate(DEFAULT_ENDDATE);
        // Add required entity
        Employee employee = EmployeeResourceIntTest.createEntity(em);
        em.persist(employee);
        em.flush();
        empvacation.setEmployee(employee);
        // Add required entity
        Vacationtype vacationtype = VacationtypeResourceIntTest.createEntity(em);
        em.persist(vacationtype);
        em.flush();
        empvacation.setVacationtype(vacationtype);
        return empvacation;
    }

    @Before
    public void initTest() {
        empvacation = createEntity(em);
    }

    @Test
    @Transactional
    public void createEmpvacation() throws Exception {
        int databaseSizeBeforeCreate = empvacationRepository.findAll().size();

        // Create the Empvacation
        restEmpvacationMockMvc.perform(post("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(empvacation)))
            .andExpect(status().isCreated());

        // Validate the Empvacation in the database
        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeCreate + 1);
        Empvacation testEmpvacation = empvacationList.get(empvacationList.size() - 1);
        assertThat(testEmpvacation.getStartdate()).isEqualTo(DEFAULT_STARTDATE);
        assertThat(testEmpvacation.getEnddate()).isEqualTo(DEFAULT_ENDDATE);

        // Validate the Empvacation in Elasticsearch
        verify(mockEmpvacationSearchRepository, times(1)).save(testEmpvacation);
    }

    @Test
    @Transactional
    public void createEmpvacationWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = empvacationRepository.findAll().size();

        // Create the Empvacation with an existing ID
        empvacation.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restEmpvacationMockMvc.perform(post("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(empvacation)))
            .andExpect(status().isBadRequest());

        // Validate the Empvacation in the database
        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeCreate);

        // Validate the Empvacation in Elasticsearch
        verify(mockEmpvacationSearchRepository, times(0)).save(empvacation);
    }

    @Test
    @Transactional
    public void checkStartdateIsRequired() throws Exception {
        int databaseSizeBeforeTest = empvacationRepository.findAll().size();
        // set the field null
        empvacation.setStartdate(null);

        // Create the Empvacation, which fails.

        restEmpvacationMockMvc.perform(post("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(empvacation)))
            .andExpect(status().isBadRequest());

        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkEnddateIsRequired() throws Exception {
        int databaseSizeBeforeTest = empvacationRepository.findAll().size();
        // set the field null
        empvacation.setEnddate(null);

        // Create the Empvacation, which fails.

        restEmpvacationMockMvc.perform(post("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(empvacation)))
            .andExpect(status().isBadRequest());

        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllEmpvacations() throws Exception {
        // Initialize the database
        empvacationRepository.saveAndFlush(empvacation);

        // Get all the empvacationList
        restEmpvacationMockMvc.perform(get("/api/empvacations?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(empvacation.getId().intValue())))
            .andExpect(jsonPath("$.[*].startdate").value(hasItem(sameInstant(DEFAULT_STARTDATE))))
            .andExpect(jsonPath("$.[*].enddate").value(hasItem(sameInstant(DEFAULT_ENDDATE))));
    }
    
    @Test
    @Transactional
    public void getEmpvacation() throws Exception {
        // Initialize the database
        empvacationRepository.saveAndFlush(empvacation);

        // Get the empvacation
        restEmpvacationMockMvc.perform(get("/api/empvacations/{id}", empvacation.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(empvacation.getId().intValue()))
            .andExpect(jsonPath("$.startdate").value(sameInstant(DEFAULT_STARTDATE)))
            .andExpect(jsonPath("$.enddate").value(sameInstant(DEFAULT_ENDDATE)));
    }

    @Test
    @Transactional
    public void getNonExistingEmpvacation() throws Exception {
        // Get the empvacation
        restEmpvacationMockMvc.perform(get("/api/empvacations/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateEmpvacation() throws Exception {
        // Initialize the database
        empvacationRepository.saveAndFlush(empvacation);

        int databaseSizeBeforeUpdate = empvacationRepository.findAll().size();

        // Update the empvacation
        Empvacation updatedEmpvacation = empvacationRepository.findById(empvacation.getId()).get();
        // Disconnect from session so that the updates on updatedEmpvacation are not directly saved in db
        em.detach(updatedEmpvacation);
        updatedEmpvacation
            .startdate(UPDATED_STARTDATE)
            .enddate(UPDATED_ENDDATE);

        restEmpvacationMockMvc.perform(put("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedEmpvacation)))
            .andExpect(status().isOk());

        // Validate the Empvacation in the database
        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeUpdate);
        Empvacation testEmpvacation = empvacationList.get(empvacationList.size() - 1);
        assertThat(testEmpvacation.getStartdate()).isEqualTo(UPDATED_STARTDATE);
        assertThat(testEmpvacation.getEnddate()).isEqualTo(UPDATED_ENDDATE);

        // Validate the Empvacation in Elasticsearch
        verify(mockEmpvacationSearchRepository, times(1)).save(testEmpvacation);
    }

    @Test
    @Transactional
    public void updateNonExistingEmpvacation() throws Exception {
        int databaseSizeBeforeUpdate = empvacationRepository.findAll().size();

        // Create the Empvacation

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restEmpvacationMockMvc.perform(put("/api/empvacations")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(empvacation)))
            .andExpect(status().isBadRequest());

        // Validate the Empvacation in the database
        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Empvacation in Elasticsearch
        verify(mockEmpvacationSearchRepository, times(0)).save(empvacation);
    }

    @Test
    @Transactional
    public void deleteEmpvacation() throws Exception {
        // Initialize the database
        empvacationRepository.saveAndFlush(empvacation);

        int databaseSizeBeforeDelete = empvacationRepository.findAll().size();

        // Get the empvacation
        restEmpvacationMockMvc.perform(delete("/api/empvacations/{id}", empvacation.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Empvacation> empvacationList = empvacationRepository.findAll();
        assertThat(empvacationList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Empvacation in Elasticsearch
        verify(mockEmpvacationSearchRepository, times(1)).deleteById(empvacation.getId());
    }

    @Test
    @Transactional
    public void searchEmpvacation() throws Exception {
        // Initialize the database
        empvacationRepository.saveAndFlush(empvacation);
        when(mockEmpvacationSearchRepository.search(queryStringQuery("id:" + empvacation.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(empvacation), PageRequest.of(0, 1), 1));
        // Search the empvacation
        restEmpvacationMockMvc.perform(get("/api/_search/empvacations?query=id:" + empvacation.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(empvacation.getId().intValue())))
            .andExpect(jsonPath("$.[*].startdate").value(hasItem(sameInstant(DEFAULT_STARTDATE))))
            .andExpect(jsonPath("$.[*].enddate").value(hasItem(sameInstant(DEFAULT_ENDDATE))));
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Empvacation.class);
        Empvacation empvacation1 = new Empvacation();
        empvacation1.setId(1L);
        Empvacation empvacation2 = new Empvacation();
        empvacation2.setId(empvacation1.getId());
        assertThat(empvacation1).isEqualTo(empvacation2);
        empvacation2.setId(2L);
        assertThat(empvacation1).isNotEqualTo(empvacation2);
        empvacation1.setId(null);
        assertThat(empvacation1).isNotEqualTo(empvacation2);
    }
}
