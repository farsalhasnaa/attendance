package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.JhipApp;

import com.mycompany.myapp.domain.Dashboard;
import com.mycompany.myapp.domain.Employee;
import com.mycompany.myapp.repository.DashboardRepository;
import com.mycompany.myapp.repository.search.DashboardSearchRepository;
import com.mycompany.myapp.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collections;
import java.util.List;


import static com.mycompany.myapp.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the DashboardResource REST controller.
 *
 * @see DashboardResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = JhipApp.class)
public class DashboardResourceIntTest {

    private static final Long DEFAULT_PERMISSION = 1L;
    private static final Long UPDATED_PERMISSION = 2L;

    private static final Long DEFAULT_ORDINARY = 1L;
    private static final Long UPDATED_ORDINARY = 2L;

    private static final Long DEFAULT_DELIVERY = 1L;
    private static final Long UPDATED_DELIVERY = 2L;

    private static final Long DEFAULT_MARRIAGE = 1L;
    private static final Long UPDATED_MARRIAGE = 2L;

    private static final LocalDate DEFAULT_REPORTDATE = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_REPORTDATE = LocalDate.now(ZoneId.systemDefault());

    private static final int DEFAULT_WEEKNUMBER = 1;
    private static final int UPDATED_WEEKNUMBER = 2;

    private static final LocalDate DEFAULT_REPORTMONTH = LocalDate.ofEpochDay(0L);
    private static final LocalDate UPDATED_REPORTMONTH = LocalDate.now(ZoneId.systemDefault());

    @Autowired
    private DashboardRepository dashboardRepository;

    /**
     * This repository is mocked in the com.mycompany.myapp.repository.search test package.
     *
     * @see com.mycompany.myapp.repository.search.DashboardSearchRepositoryMockConfiguration
     */
    @Autowired
    private DashboardSearchRepository mockDashboardSearchRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restDashboardMockMvc;

    private Dashboard dashboard;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final DashboardResource dashboardResource = new DashboardResource(dashboardRepository, mockDashboardSearchRepository);
        this.restDashboardMockMvc = MockMvcBuilders.standaloneSetup(dashboardResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Dashboard createEntity(EntityManager em) {
        Dashboard dashboard = new Dashboard()
            .permission(DEFAULT_PERMISSION)
            .ordinary(DEFAULT_ORDINARY)
            .delivery(DEFAULT_DELIVERY)
            .marriage(DEFAULT_MARRIAGE)
            .reportdate(DEFAULT_REPORTDATE)
            .weeknumber(DEFAULT_WEEKNUMBER)
            .reportmonth(DEFAULT_REPORTMONTH);
        // Add required entity
        Employee employee = EmployeeResourceIntTest.createEntity(em);
        em.persist(employee);
        em.flush();
        dashboard.setEmployee(employee);
        return dashboard;
    }

    @Before
    public void initTest() {
        dashboard = createEntity(em);
    }

    @Test
    @Transactional
    public void createDashboard() throws Exception {
        int databaseSizeBeforeCreate = dashboardRepository.findAll().size();

        // Create the Dashboard
        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isCreated());

        // Validate the Dashboard in the database
        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeCreate + 1);
        Dashboard testDashboard = dashboardList.get(dashboardList.size() - 1);
        assertThat(testDashboard.getPermission()).isEqualTo(DEFAULT_PERMISSION);
        assertThat(testDashboard.getOrdinary()).isEqualTo(DEFAULT_ORDINARY);
        assertThat(testDashboard.getDelivery()).isEqualTo(DEFAULT_DELIVERY);
        assertThat(testDashboard.getMarriage()).isEqualTo(DEFAULT_MARRIAGE);
        assertThat(testDashboard.getReportdate()).isEqualTo(DEFAULT_REPORTDATE);
        assertThat(testDashboard.getWeeknumber()).isEqualTo(DEFAULT_WEEKNUMBER);
        assertThat(testDashboard.getReportmonth()).isEqualTo(DEFAULT_REPORTMONTH);

        // Validate the Dashboard in Elasticsearch
        verify(mockDashboardSearchRepository, times(1)).save(testDashboard);
    }

    @Test
    @Transactional
    public void createDashboardWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = dashboardRepository.findAll().size();

        // Create the Dashboard with an existing ID
        dashboard.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        // Validate the Dashboard in the database
        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeCreate);

        // Validate the Dashboard in Elasticsearch
        verify(mockDashboardSearchRepository, times(0)).save(dashboard);
    }

    @Test
    @Transactional
    public void checkPermissionIsRequired() throws Exception {
        int databaseSizeBeforeTest = dashboardRepository.findAll().size();
        // set the field null
        dashboard.setPermission(null);

        // Create the Dashboard, which fails.

        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkOrdinaryIsRequired() throws Exception {
        int databaseSizeBeforeTest = dashboardRepository.findAll().size();
        // set the field null
        dashboard.setOrdinary(null);

        // Create the Dashboard, which fails.

        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkDeliveryIsRequired() throws Exception {
        int databaseSizeBeforeTest = dashboardRepository.findAll().size();
        // set the field null
        dashboard.setDelivery(null);

        // Create the Dashboard, which fails.

        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void checkMarriageIsRequired() throws Exception {
        int databaseSizeBeforeTest = dashboardRepository.findAll().size();
        // set the field null
        dashboard.setMarriage(null);

        // Create the Dashboard, which fails.

        restDashboardMockMvc.perform(post("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllDashboards() throws Exception {
        // Initialize the database
        dashboardRepository.saveAndFlush(dashboard);

        // Get all the dashboardList
        restDashboardMockMvc.perform(get("/api/dashboards?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(dashboard.getId().intValue())))
            .andExpect(jsonPath("$.[*].permission").value(hasItem(DEFAULT_PERMISSION.intValue())))
            .andExpect(jsonPath("$.[*].ordinary").value(hasItem(DEFAULT_ORDINARY.intValue())))
            .andExpect(jsonPath("$.[*].delivery").value(hasItem(DEFAULT_DELIVERY.intValue())))
            .andExpect(jsonPath("$.[*].marriage").value(hasItem(DEFAULT_MARRIAGE.intValue())))
            .andExpect(jsonPath("$.[*].reportdate").value(hasItem(DEFAULT_REPORTDATE.toString())))
            .andExpect(jsonPath("$.[*].weeknumber").value(hasItem(DEFAULT_WEEKNUMBER)))
            .andExpect(jsonPath("$.[*].reportmonth").value(hasItem(DEFAULT_REPORTMONTH.toString())));
    }
    
    @Test
    @Transactional
    public void getDashboard() throws Exception {
        // Initialize the database
        dashboardRepository.saveAndFlush(dashboard);

        // Get the dashboard
        restDashboardMockMvc.perform(get("/api/dashboards/{id}", dashboard.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(dashboard.getId().intValue()))
            .andExpect(jsonPath("$.permission").value(DEFAULT_PERMISSION.intValue()))
            .andExpect(jsonPath("$.ordinary").value(DEFAULT_ORDINARY.intValue()))
            .andExpect(jsonPath("$.delivery").value(DEFAULT_DELIVERY.intValue()))
            .andExpect(jsonPath("$.marriage").value(DEFAULT_MARRIAGE.intValue()))
            .andExpect(jsonPath("$.reportdate").value(DEFAULT_REPORTDATE.toString()))
            .andExpect(jsonPath("$.weeknumber").value(DEFAULT_WEEKNUMBER))
            .andExpect(jsonPath("$.reportmonth").value(DEFAULT_REPORTMONTH.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingDashboard() throws Exception {
        // Get the dashboard
        restDashboardMockMvc.perform(get("/api/dashboards/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateDashboard() throws Exception {
        // Initialize the database
        dashboardRepository.saveAndFlush(dashboard);

        int databaseSizeBeforeUpdate = dashboardRepository.findAll().size();

        // Update the dashboard
        Dashboard updatedDashboard = dashboardRepository.findById(dashboard.getId()).get();
        // Disconnect from session so that the updates on updatedDashboard are not directly saved in db
        em.detach(updatedDashboard);
        updatedDashboard
            .permission(UPDATED_PERMISSION)
            .ordinary(UPDATED_ORDINARY)
            .delivery(UPDATED_DELIVERY)
            .marriage(UPDATED_MARRIAGE)
            .reportdate(UPDATED_REPORTDATE)
            .weeknumber(UPDATED_WEEKNUMBER)
            .reportmonth(UPDATED_REPORTMONTH);

        restDashboardMockMvc.perform(put("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedDashboard)))
            .andExpect(status().isOk());

        // Validate the Dashboard in the database
        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeUpdate);
        Dashboard testDashboard = dashboardList.get(dashboardList.size() - 1);
        assertThat(testDashboard.getPermission()).isEqualTo(UPDATED_PERMISSION);
        assertThat(testDashboard.getOrdinary()).isEqualTo(UPDATED_ORDINARY);
        assertThat(testDashboard.getDelivery()).isEqualTo(UPDATED_DELIVERY);
        assertThat(testDashboard.getMarriage()).isEqualTo(UPDATED_MARRIAGE);
        assertThat(testDashboard.getReportdate()).isEqualTo(UPDATED_REPORTDATE);
        assertThat(testDashboard.getWeeknumber()).isEqualTo(UPDATED_WEEKNUMBER);
        assertThat(testDashboard.getReportmonth()).isEqualTo(UPDATED_REPORTMONTH);

        // Validate the Dashboard in Elasticsearch
        verify(mockDashboardSearchRepository, times(1)).save(testDashboard);
    }

    @Test
    @Transactional
    public void updateNonExistingDashboard() throws Exception {
        int databaseSizeBeforeUpdate = dashboardRepository.findAll().size();

        // Create the Dashboard

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restDashboardMockMvc.perform(put("/api/dashboards")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(dashboard)))
            .andExpect(status().isBadRequest());

        // Validate the Dashboard in the database
        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Dashboard in Elasticsearch
        verify(mockDashboardSearchRepository, times(0)).save(dashboard);
    }

    @Test
    @Transactional
    public void deleteDashboard() throws Exception {
        // Initialize the database
        dashboardRepository.saveAndFlush(dashboard);

        int databaseSizeBeforeDelete = dashboardRepository.findAll().size();

        // Get the dashboard
        restDashboardMockMvc.perform(delete("/api/dashboards/{id}", dashboard.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Dashboard> dashboardList = dashboardRepository.findAll();
        assertThat(dashboardList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Dashboard in Elasticsearch
        verify(mockDashboardSearchRepository, times(1)).deleteById(dashboard.getId());
    }

    @Test
    @Transactional
    public void searchDashboard() throws Exception {
        // Initialize the database
        dashboardRepository.saveAndFlush(dashboard);
        when(mockDashboardSearchRepository.search(queryStringQuery("id:" + dashboard.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(dashboard), PageRequest.of(0, 1), 1));
        // Search the dashboard
        restDashboardMockMvc.perform(get("/api/_search/dashboards?query=id:" + dashboard.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(dashboard.getId().intValue())))
            .andExpect(jsonPath("$.[*].permission").value(hasItem(DEFAULT_PERMISSION.intValue())))
            .andExpect(jsonPath("$.[*].ordinary").value(hasItem(DEFAULT_ORDINARY.intValue())))
            .andExpect(jsonPath("$.[*].delivery").value(hasItem(DEFAULT_DELIVERY.intValue())))
            .andExpect(jsonPath("$.[*].marriage").value(hasItem(DEFAULT_MARRIAGE.intValue())))
            .andExpect(jsonPath("$.[*].reportdate").value(hasItem(DEFAULT_REPORTDATE.toString())))
            .andExpect(jsonPath("$.[*].weeknumber").value(hasItem(DEFAULT_WEEKNUMBER)))
            .andExpect(jsonPath("$.[*].reportmonth").value(hasItem(DEFAULT_REPORTMONTH.toString())));
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Dashboard.class);
        Dashboard dashboard1 = new Dashboard();
        dashboard1.setId(1L);
        Dashboard dashboard2 = new Dashboard();
        dashboard2.setId(dashboard1.getId());
        assertThat(dashboard1).isEqualTo(dashboard2);
        dashboard2.setId(2L);
        assertThat(dashboard1).isNotEqualTo(dashboard2);
        dashboard1.setId(null);
        assertThat(dashboard1).isNotEqualTo(dashboard2);
    }
}
