package com.mycompany.myapp.web.rest;

import com.mycompany.myapp.JhipApp;

import com.mycompany.myapp.domain.Vacationtype;
import com.mycompany.myapp.repository.VacationtypeRepository;
import com.mycompany.myapp.repository.search.VacationtypeSearchRepository;
import com.mycompany.myapp.web.rest.errors.ExceptionTranslator;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.Validator;

import javax.persistence.EntityManager;
import java.util.Collections;
import java.util.List;


import static com.mycompany.myapp.web.rest.TestUtil.createFormattingConversionService;
import static org.assertj.core.api.Assertions.assertThat;
import static org.elasticsearch.index.query.QueryBuilders.queryStringQuery;
import static org.hamcrest.Matchers.hasItem;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the VacationtypeResource REST controller.
 *
 * @see VacationtypeResource
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = JhipApp.class)
public class VacationtypeResourceIntTest {

    private static final String DEFAULT_VACATIONNAME = "AAAAAAAAAA";
    private static final String UPDATED_VACATIONNAME = "BBBBBBBBBB";

    @Autowired
    private VacationtypeRepository vacationtypeRepository;

    /**
     * This repository is mocked in the com.mycompany.myapp.repository.search test package.
     *
     * @see com.mycompany.myapp.repository.search.VacationtypeSearchRepositoryMockConfiguration
     */
    @Autowired
    private VacationtypeSearchRepository mockVacationtypeSearchRepository;

    @Autowired
    private MappingJackson2HttpMessageConverter jacksonMessageConverter;

    @Autowired
    private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

    @Autowired
    private ExceptionTranslator exceptionTranslator;

    @Autowired
    private EntityManager em;

    @Autowired
    private Validator validator;

    private MockMvc restVacationtypeMockMvc;

    private Vacationtype vacationtype;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        final VacationtypeResource vacationtypeResource = new VacationtypeResource(vacationtypeRepository, mockVacationtypeSearchRepository);
        this.restVacationtypeMockMvc = MockMvcBuilders.standaloneSetup(vacationtypeResource)
            .setCustomArgumentResolvers(pageableArgumentResolver)
            .setControllerAdvice(exceptionTranslator)
            .setConversionService(createFormattingConversionService())
            .setMessageConverters(jacksonMessageConverter)
            .setValidator(validator).build();
    }

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Vacationtype createEntity(EntityManager em) {
        Vacationtype vacationtype = new Vacationtype()
            .vacationname(DEFAULT_VACATIONNAME);
        return vacationtype;
    }

    @Before
    public void initTest() {
        vacationtype = createEntity(em);
    }

    @Test
    @Transactional
    public void createVacationtype() throws Exception {
        int databaseSizeBeforeCreate = vacationtypeRepository.findAll().size();

        // Create the Vacationtype
        restVacationtypeMockMvc.perform(post("/api/vacationtypes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(vacationtype)))
            .andExpect(status().isCreated());

        // Validate the Vacationtype in the database
        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeCreate + 1);
        Vacationtype testVacationtype = vacationtypeList.get(vacationtypeList.size() - 1);
        assertThat(testVacationtype.getVacationname()).isEqualTo(DEFAULT_VACATIONNAME);

        // Validate the Vacationtype in Elasticsearch
        verify(mockVacationtypeSearchRepository, times(1)).save(testVacationtype);
    }

    @Test
    @Transactional
    public void createVacationtypeWithExistingId() throws Exception {
        int databaseSizeBeforeCreate = vacationtypeRepository.findAll().size();

        // Create the Vacationtype with an existing ID
        vacationtype.setId(1L);

        // An entity with an existing ID cannot be created, so this API call must fail
        restVacationtypeMockMvc.perform(post("/api/vacationtypes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(vacationtype)))
            .andExpect(status().isBadRequest());

        // Validate the Vacationtype in the database
        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeCreate);

        // Validate the Vacationtype in Elasticsearch
        verify(mockVacationtypeSearchRepository, times(0)).save(vacationtype);
    }

    @Test
    @Transactional
    public void checkVacationnameIsRequired() throws Exception {
        int databaseSizeBeforeTest = vacationtypeRepository.findAll().size();
        // set the field null
        vacationtype.setVacationname(null);

        // Create the Vacationtype, which fails.

        restVacationtypeMockMvc.perform(post("/api/vacationtypes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(vacationtype)))
            .andExpect(status().isBadRequest());

        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    public void getAllVacationtypes() throws Exception {
        // Initialize the database
        vacationtypeRepository.saveAndFlush(vacationtype);

        // Get all the vacationtypeList
        restVacationtypeMockMvc.perform(get("/api/vacationtypes?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(vacationtype.getId().intValue())))
            .andExpect(jsonPath("$.[*].vacationname").value(hasItem(DEFAULT_VACATIONNAME.toString())));
    }
    
    @Test
    @Transactional
    public void getVacationtype() throws Exception {
        // Initialize the database
        vacationtypeRepository.saveAndFlush(vacationtype);

        // Get the vacationtype
        restVacationtypeMockMvc.perform(get("/api/vacationtypes/{id}", vacationtype.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.id").value(vacationtype.getId().intValue()))
            .andExpect(jsonPath("$.vacationname").value(DEFAULT_VACATIONNAME.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingVacationtype() throws Exception {
        // Get the vacationtype
        restVacationtypeMockMvc.perform(get("/api/vacationtypes/{id}", Long.MAX_VALUE))
            .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateVacationtype() throws Exception {
        // Initialize the database
        vacationtypeRepository.saveAndFlush(vacationtype);

        int databaseSizeBeforeUpdate = vacationtypeRepository.findAll().size();

        // Update the vacationtype
        Vacationtype updatedVacationtype = vacationtypeRepository.findById(vacationtype.getId()).get();
        // Disconnect from session so that the updates on updatedVacationtype are not directly saved in db
        em.detach(updatedVacationtype);
        updatedVacationtype
            .vacationname(UPDATED_VACATIONNAME);

        restVacationtypeMockMvc.perform(put("/api/vacationtypes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(updatedVacationtype)))
            .andExpect(status().isOk());

        // Validate the Vacationtype in the database
        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeUpdate);
        Vacationtype testVacationtype = vacationtypeList.get(vacationtypeList.size() - 1);
        assertThat(testVacationtype.getVacationname()).isEqualTo(UPDATED_VACATIONNAME);

        // Validate the Vacationtype in Elasticsearch
        verify(mockVacationtypeSearchRepository, times(1)).save(testVacationtype);
    }

    @Test
    @Transactional
    public void updateNonExistingVacationtype() throws Exception {
        int databaseSizeBeforeUpdate = vacationtypeRepository.findAll().size();

        // Create the Vacationtype

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restVacationtypeMockMvc.perform(put("/api/vacationtypes")
            .contentType(TestUtil.APPLICATION_JSON_UTF8)
            .content(TestUtil.convertObjectToJsonBytes(vacationtype)))
            .andExpect(status().isBadRequest());

        // Validate the Vacationtype in the database
        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeUpdate);

        // Validate the Vacationtype in Elasticsearch
        verify(mockVacationtypeSearchRepository, times(0)).save(vacationtype);
    }

    @Test
    @Transactional
    public void deleteVacationtype() throws Exception {
        // Initialize the database
        vacationtypeRepository.saveAndFlush(vacationtype);

        int databaseSizeBeforeDelete = vacationtypeRepository.findAll().size();

        // Get the vacationtype
        restVacationtypeMockMvc.perform(delete("/api/vacationtypes/{id}", vacationtype.getId())
            .accept(TestUtil.APPLICATION_JSON_UTF8))
            .andExpect(status().isOk());

        // Validate the database is empty
        List<Vacationtype> vacationtypeList = vacationtypeRepository.findAll();
        assertThat(vacationtypeList).hasSize(databaseSizeBeforeDelete - 1);

        // Validate the Vacationtype in Elasticsearch
        verify(mockVacationtypeSearchRepository, times(1)).deleteById(vacationtype.getId());
    }

    @Test
    @Transactional
    public void searchVacationtype() throws Exception {
        // Initialize the database
        vacationtypeRepository.saveAndFlush(vacationtype);
        when(mockVacationtypeSearchRepository.search(queryStringQuery("id:" + vacationtype.getId()), PageRequest.of(0, 20)))
            .thenReturn(new PageImpl<>(Collections.singletonList(vacationtype), PageRequest.of(0, 1), 1));
        // Search the vacationtype
        restVacationtypeMockMvc.perform(get("/api/_search/vacationtypes?query=id:" + vacationtype.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(vacationtype.getId().intValue())))
            .andExpect(jsonPath("$.[*].vacationname").value(hasItem(DEFAULT_VACATIONNAME)));
    }

    @Test
    @Transactional
    public void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Vacationtype.class);
        Vacationtype vacationtype1 = new Vacationtype();
        vacationtype1.setId(1L);
        Vacationtype vacationtype2 = new Vacationtype();
        vacationtype2.setId(vacationtype1.getId());
        assertThat(vacationtype1).isEqualTo(vacationtype2);
        vacationtype2.setId(2L);
        assertThat(vacationtype1).isNotEqualTo(vacationtype2);
        vacationtype1.setId(null);
        assertThat(vacationtype1).isNotEqualTo(vacationtype2);
    }
}
